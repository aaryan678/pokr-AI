#main function calls everything and returns a list of the players who won, and the amount of they should rec.
def winner(holeCards, communityCards, sidePot, potSize, foldedPlayer):
    # Calculate the scores of each player
    playerScores = []
    for player in holeCards:
        if player not in foldedPlayer:
            hand = holeCards[player]
            score = scoreHand(hand, communityCards)
            playerScores.append((player, score))
    
    # Sort the list of player scores in descending order
    n = len(playerScores)
    for i in range(n):
        for j in range(0, n-i-1):
            if playerScores[j][1] < playerScores[j+1][1]:
                playerScores[j], playerScores[j+1] = playerScores[j+1], playerScores[j]
    playerScoresDict = {}
    for player, score in playerScores:
        playerScoresDict[player] = score

    return potDistribution(playerScoresDict,sidePot, potSize)

#Distributes the pot, sidepot and main pot 
def potDistribution(playerScores, sidePot, potSize):
    TotalAmountGiven = 0
    copySidePot = sidePot.copy()
    copyPlayerScores = playerScores.copy()
    remainingAmount = potSize
    dictForpotAmountReceived = {}
    while len(copySidePot) > 0:
        minValue = min(copySidePot.values())
        listOfPlayersWhoWon = []
        highestScore = 0
        for player, score in copyPlayerScores.items():
            if score > highestScore:
                highestScore = score
                listOfPlayersWhoWon = [player]
            elif score == highestScore:
                listOfPlayersWhoWon.append(player)
                
        valueToBeDistributed = minValue - TotalAmountGiven
        TotalAmountGiven += valueToBeDistributed
        remainingAmount -= valueToBeDistributed
        for player in listOfPlayersWhoWon:
            dictForpotAmountReceived[player] = valueToBeDistributed
        keysToRemove = [k for k, v in copySidePot.items() if v == minValue]
        for key in keysToRemove:
            copySidePot.pop(key)
            copyPlayerScores.pop(key)
    else:
        listOfPlayersWhoWon = []
        highestScore = 0
        for player, score in copyPlayerScores.items():
            if score > highestScore:
                highestScore = score
                listOfPlayersWhoWon = [player]
            elif score == highestScore:
                listOfPlayersWhoWon.append(player)
        for player in listOfPlayersWhoWon:
            if player not in dictForpotAmountReceived:
                dictForpotAmountReceived[player] = round(remainingAmount / len(listOfPlayersWhoWon), 0)
            else:
                dictForpotAmountReceived[player] += round(remainingAmount / len(listOfPlayersWhoWon), 0)
    return dictForpotAmountReceived

#calls helpers and scores a hand points based system    
def scoreHand(hand,communityCards):

    listOfRankedCards,suits = getDictOfCards(hand,communityCards)
    straightFlushValidity, byRankSf = straightFlush(listOfRankedCards, suits)
    fourOfAKindValidity, byRank4k = fourOfAKind(listOfRankedCards)
    fullHouseValidity, byRankFh = fullHouse(listOfRankedCards)
    flushValidity, byRankFl = flush(listOfRankedCards, suits)
    straightValidity, byRankst = straight(listOfRankedCards)
    threeOfakKindValidity, byRank3k = threeOfaKind(listOfRankedCards)
    twoPairValidity, byRank2P= twoPair(listOfRankedCards)
    pairValidity, byRankP = pair(listOfRankedCards)
    highCardValidity, byRankHc = highCard(listOfRankedCards)

    if royalFlush(listOfRankedCards,suits) == True:
        return 10000
    elif straightFlushValidity == True:
        return 9000 + byRankSf
    elif fourOfAKindValidity == True:
        return 8000 + byRank4k
    elif fullHouseValidity == True:
        return 7000 + (byRankFh[0]*10)+byRankFh[1]
    elif flushValidity == True:
        return 6000 + byRankFl
    elif straightValidity == True:
        return 5000 + byRankst
    elif threeOfakKindValidity == True:
        return 4000 + byRank3k
    elif twoPairValidity == True:
        return 3000 + byRank2P[0]+byRank2P[1]
    elif pairValidity == True:
        return 2000 + byRankP
    elif highCardValidity == True:
        return 1000 + byRankHc 

#ranks card according to number, deuce is 2 and Ace is 14, Ace can only be 1 but I am taking as 14 
def rankCard(cards):
    result = []
    values = {
            "Deuce": 2,
            "Three": 3,
            "Four": 4,
            "Five": 5,
            "Six": 6,
            "Seven": 7,
            "Eight": 8,
            "Nine": 9,
            "Ten": 10,
            "Jack": 11,
            "Queen": 12,
            "King": 13,
            "Ace": 14
        }
    for i in cards:
        valuePair = values[i]
        result.append(valuePair)
    return result

def getDictOfCards(hand,communityCards):
    combined = hand + communityCards
    cards = []
    suits = []
    dictOfCards = dict()
    for hands in combined:
        hands = str(hands)
        indexSpace = hands.index(" ")
        indexOf = hands.index("of")
        card = hands[0:indexSpace]
        suit = hands[indexOf+3:]
        cards.append(card)
        suits.append(suit)
    listOfRankedCards = rankCard(cards)

    return listOfRankedCards,suits
#returns if Royal FLUSH can only be 1 so no point returning rank
def royalFlush(listOfRankedCards,suits):
    dictMappingSuitCount = dict()
    for suit in suits:
        if suit not in dictMappingSuitCount:
            dictMappingSuitCount[suit] = 1
        else:
            dictMappingSuitCount[suit] += 1
    if max(dictMappingSuitCount.values()) >= 5:
        royalFlushsuit = None
        for i in dictMappingSuitCount:
            if dictMappingSuitCount[i] >= 5:
                royalFlushsuit = i

        Sortedset = set(sorted(listOfRankedCards))
        if 10 in Sortedset and 11 in Sortedset and 12 in Sortedset and 13 in Sortedset and 14 in Sortedset:
            indexofTen = listOfRankedCards.index(10)
            indexofEleven = listOfRankedCards.index(11)
            indexofTwelve = listOfRankedCards.index(12)
            indexofThirteen = listOfRankedCards.index(13)
            indexofFourteen = listOfRankedCards.index(14)

            if (suits[indexofTen] == royalFlushsuit and suits[indexofEleven] == royalFlushsuit
                and suits[indexofTwelve] == royalFlushsuit and suits[indexofThirteen] == royalFlushsuit
                and suits[indexofFourteen] == royalFlushsuit):
                return True
            else:
                return False
    else:
        return False
        
#tests for straightFlush and returns the highest rank of the card 
def straightFlush(listOfRankedCards, suits):
    flushValidity,flushRank = flush(listOfRankedCards, suits)
    straightValidity,straightRank = straight(listOfRankedCards)
    if flushValidity == straightValidity == True:
        if flushRank == straightRank:
            return True,flushRank
        elif straightRank == 5 and flushRank == 14:
            return True, flushRank
        else:
            # Check if there is another possible straight flush
            flushSuit = None
            for suit in set(suits):
                if suits.count(suit) >= 5:
                    flushCards = [listOfRankedCards[i] for i in range(len(suits)) if suits[i] == suit]
                    flushCardsSorted = sorted(flushCards)
                    flushCardsReversed = flushCardsSorted[::-1]
                    highestFlushCards = flushCardsReversed[:5]
                    straightFlushValidity, straightFlushRank = straight(highestFlushCards)
                    if straightFlushValidity == True:
                        return True, max(highestFlushCards)
            # No other straight flush found
            return False, None
    else:
        return False, None

def fourOfAKind(listOfRankedCards):
    dictForMapping = dict()
    for card in listOfRankedCards:
        if card not in dictForMapping:
            dictForMapping[card] = 1
        else:
            dictForMapping[card] += 1
    for rank, count in dictForMapping.items():
        if count == 4:
            return True, rank
    else:
        return False, None

# returns full house or not and tuple, with first elem the trip and second elem the pair
def fullHouse(listOfRankedCards):
    tripValidity,trip = threeOfaKind(listOfRankedCards)
    poppedList = []
    if tripValidity == True:
        for i in range (len(listOfRankedCards)):
            if listOfRankedCards[i] != trip:
                poppedList.append(listOfRankedCards[i])
        pairValidity,pair_ = pair(poppedList)
        if pairValidity == True:
            rank = [trip]+[pair_]
            return True,tuple(rank)
        else:
            return False,None
    else:
        return False,None

# returns if flush exists and the highest card by which it is forming
def flush(listOfRankedCards, suits):
    dictMappingSuitCount = {}
    for suit in suits:
        if suit not in dictMappingSuitCount:
            dictMappingSuitCount[suit] = 1
        else:
            dictMappingSuitCount[suit] += 1
    if max(dictMappingSuitCount.values()) >= 5:
        flushSuit = None
        for suit in dictMappingSuitCount:
            if dictMappingSuitCount[suit] >= 5:
                flushSuit = suit
                break
        if flushSuit is not None:
            flushCards = []
            for i in range(len(listOfRankedCards)):
                if suits[i] == flushSuit:
                    flushCards.append(listOfRankedCards[i])
            flushCardsSorted = sorted(flushCards)
            flushCardsReversed = flushCardsSorted[::-1]
            highestFlushCards = flushCardsReversed[:5]
            return True, max(highestFlushCards)
    return False, None
 
def straight(listOfRankedCards):
    sortedlistset = list(set(listOfRankedCards))
    inverse = sortedlistset[::-1]
    # inverse = set(inverse)
    for e in inverse:
        for i in range(5):
            if e+i in inverse:
                continue
            else:
                break
        else:
            return True, e+4 #we can compare highest card, instead of the whole list of of cards

    # check for low straight
    if 14 in inverse: 
        inverse.append(1)
        inverse.remove(14)
        for i in range(5):
            if 1+i in inverse:
                continue
            else:
                return False, None
        else:
            return True, 5  # Ace-low straight always 5

    return False, None

#gets the highest 3 of kind that exists, did that so can use as helper for fullHouse
def threeOfaKind(listOfRankedCards):
    dictForMapping = dict()
    for card in listOfRankedCards:
        if card not in dictForMapping:
            dictForMapping[card] = 1
        else:
            dictForMapping[card] += 1
    getHighest = []
    for rank in dictForMapping:
        if dictForMapping[rank] == 3:
            getHighest.append(rank)
    if len(getHighest) >0:
        return True,max(getHighest)
    else:
        return False,None

#returns if two pair exists and a tuple of the pairs, if three 2 pairs still works
def twoPair(listOfRankedCards):
    pairs = []
    for rank in listOfRankedCards:
        if listOfRankedCards.count(rank) == 2:
            pairs.append(rank)
    if len(set(pairs)) >= 2:
        pairsSorted = sorted(pairs)
        pairsReversed = pairsSorted[::-1]
        topTwoPairs = set(pairsReversed[0:4])
        return True, tuple(topTwoPairs)
    else:
        return False, None

#returns if pair exists and pair
def pair(listOfRankedCards):
    for rank in set(listOfRankedCards):
        getCount = listOfRankedCards.count(rank)
        if getCount == 2:
            return True, rank
    else:
        return False,None

#returns high card
def highCard(listOfRankedCards):
    highest = max(listOfRankedCards)
    return True, highest
