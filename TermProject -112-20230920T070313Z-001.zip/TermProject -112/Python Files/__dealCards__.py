import __deck__ as deck

# define a Player class with a hand, name, and chip count attribute, and add methods to add cards and clear the hand
class Player:
    def __init__(self, name, chipCount):
        self.hand = []
        self.name = name
        self.chipCount = chipCount
    
    def addCards(self, cards):
        self.hand += cards
    
    def clear_hand(self):
        self.hand = []

# create a shuffled deck of cards using the ShuffledDeck class from the deck module
shuffledDeck = deck.ShuffledDeck()

class Dealer:
    def __init__(self, players):
        self.deck = shuffledDeck
        self.players = players
    
    def deal(self):
        hands = []
        # deal two cards to each player
        for i in range(2):
            for player in self.players:
                # get the top card from the shuffled deck
                card = self.deck.pop(0)
                # add the card to the player's hand
                player.addCards([card])

        for player in self.players:
            hands.append(f"{player.name}'s hand: {player.hand}")
        return hands,shuffledDeck

# players = [Player("P1", 100), Player("P2", 50), Player("P3", 75)]
# deal = Dealer(players)
# output = deal.deal()
# print(output)

