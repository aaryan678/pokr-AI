import __deck__ as deck
import __checkWinner__ as winner
from cmu_graphics import *
import math
# from PIL import Image
# import os
# import pathlib



class TexasHoldem:
    def __init__(self, players):
        self.deck = []
        self.players = list(players.keys()) # convert dictionary keys to a list of players
        self.stacks = players # store the player stacks in a dictionary
        self.dealerPosition = 0
        self.smallBlindPosition = 0
        self.bigBlindPosition = 0
        self.smallBlind = 10
        self.bigBlind = 20
        self.potSize = 0
        self.communityCards = []
        self.holeCards = {}
        self.bettingRound = ''
        self.betAmounts = {}
        self.counter = 0
        self.currentBet = self.bigBlind 
        self.foldedPlayers = set()
        self.winningHand = []
        self.currentPlayerPosition = (self.dealerPosition - 4) % len(self.players)
        self.currentPlayer = self.players[self.currentPlayerPosition]
        self.raiseOccurred = False
        self.raiseCount = 0
        self.nextPlayerIndex = (self.currentPlayerPosition - 1)
        self.allIn = []
        self.sidePot = dict()
        self.lastRaiseAmount = 0
        self.gameOver = False
        self.initializeGame()

    def nextRound(self):
        self.deck = []
        self.dealerPosition += 1
        self.smallBlindPosition = 0
        self.bigBlindPosition = 0
        self.smallBlind = 10
        self.bigBlind = 20
        self.potSize = 0
        self.communityCards = []
        self.holeCards = {}
        self.bettingRound = ''
        self.betAmounts = {}
        self.counter = 0
        self.currentBet = self.bigBlind 
        self.foldedPlayers = set()
        self.winningHand = []
        self.currentPlayerPosition = (self.dealerPosition - 4) % len(self.players)
        self.currentPlayer = self.players[self.currentPlayerPosition]
        self.raiseOccurred = False
        self.raiseCount = 0
        self.nextPlayerIndex = (self.currentPlayerPosition - 1)
        self.allIn = []
        self.sidePot = dict()
        self.lastRaiseAmount = 0
        self.gameOver = False
        self.initializeGame()


    def initializeGame(self):
        self.deck = deck.ShuffledDeck()
        self.dealHoleCards()
        self.setDealerPosition()
        self.setBetAmounts()
        self.setBlinds()
        self.bettingRound = 'preflop'
    
    def dealHoleCards(self):
        for player in self.players:
            self.holeCards[player] = [self.deck.pop(0), self.deck.pop(0)]

    def setDealerPosition(self):
        self.dealerPosition = (self.dealerPosition -1 ) % len(self.players)

    def setBetAmounts(self):
        roundList = ["preflop", "flop", "turn", "river"]
        for player in self.players:
            self.betAmounts[player] = {}
            for round in roundList:
                self.betAmounts[player][round] = 0
        
    def setBlinds(self):
        self.smallBlindPosition = (self.dealerPosition -1 ) % len(self.players)
        self.bigBlindPosition = (self.dealerPosition - 2) % len(self.players)

        self.betAmounts[self.players[self.smallBlindPosition]]["preflop"] = self.smallBlind
        self.betAmounts[self.players[self.bigBlindPosition]]["preflop"] = self.bigBlind

        self.stacks[self.players[self.smallBlindPosition]] -= self.smallBlind
        self.stacks[self.players[self.bigBlindPosition]] -= self.bigBlind
        
        self.potSize = self.smallBlind + self.bigBlind
    
    def flop(self):
        self.deck.pop(0)
        self.communityCards += [self.deck.pop(0), self.deck.pop(0),self.deck.pop(0)]

    def turn(self):
        self.deck.pop(0)
        self.communityCards += [self.deck.pop(0)]

    def river(self):
        self.deck.pop(0)
        self.communityCards += [self.deck.pop(0)]

    def handleFold(self, player):
        self.counter += 1
        self.foldedPlayers.add(player)
        self.betAmounts.pop(player)

    def handleCall(self, player):
        amountToCall = self.currentBet - self.betAmounts[player][self.bettingRound] # subtracting the previous bet amount
        if amountToCall > self.stacks[player]:
            amountToCall = self.stacks[player]
        self.stacks[player] -= amountToCall
        self.betAmounts[player][self.bettingRound] += amountToCall
        self.potSize += amountToCall
        self.counter += 1

    def handleRaise(self, player, ifRaise):
        # if self.raiseCount == 0:
        #     amountToRaise = ifRaise #- self.smallBlind
        # else:
        amountToRaise = ifRaise
        if amountToRaise > self.stacks[player]:
            amountToRaise = self.stacks[player]
        self.stacks[player] -= amountToRaise
        self.currentBet = abs((amountToRaise + self.lastRaiseAmount) - self.betAmounts[player][self.bettingRound])
        self.betAmounts[player][self.bettingRound] += abs(amountToRaise-self.betAmounts[player][self.bettingRound])
        self.potSize += amountToRaise
        self.lastPlayerToRaise = player
        self.raiseOccurred = True
        self.counter  = 0
        self.raiseCount += 1
        self.lastRaiseAmount = amountToRaise
        
    def handleCheck(self, player):
        if self.currentBet != self.bigBlind:
            if (self.players.index(player) == self.bigBlindPosition) or (self.players.index(player) == self.smallBlindPosition):
                self.counter += 1
        elif (self.currentBet == self.bigBlind) and (self.players.index(player) == self.bigBlindPosition):
            self.counter += 1

    def endBettingRound(self):
        round = self.bettingRound
        betAmount = set()
        for player in self.players:
            betAmount.add(self.betAmounts[player][round])
        if len(betAmount) == 1:
            return True
        else:
            return False

    def updateAllIn(self,player):
        if self.stacks[player] == 0 or player in self.foldedPlayers:
            self.allIn.append(self.currentPlayerPosition)
        if self.stacks[player] == 0:
            self.sidePot[player] = self.potSize

    def getNextPlayerPosition(self):
        nextPlayerPosition = (self.currentPlayerPosition - 1) % len(self.players)
        for i in range(len(self.players)-1):
            if nextPlayerPosition in self.allIn:
                nextPlayerPosition = (nextPlayerPosition - 1) % len(self.players)
            else:
                break
        else:
            nextPlayerPosition = None
        return nextPlayerPosition

    def updateCurrentPlayerPosition(self, nextPlayerPosition):
        if nextPlayerPosition is None:
            self.currentPlayerPosition = self.currentPlayerPosition
        else:
            self.currentPlayerPosition = nextPlayerPosition
            self.currentPlayer = self.players[self.currentPlayerPosition]

    def distributeToWinners(self,division):
        for player in division:
            print(player)
            print(division[player])
            self.stacks[player] += division[player]
            print(self.stacks)

    def runBettingRound(self, player, move, ifRaise=None):
        if self.bettingRound == 'preflop':
            self.runPreflop(player, move, ifRaise)
            if len(self.allIn) >= (len(self.players)-1):
                division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
                self.distributeToWinners(division)
                self.gameOver = True
        elif self.bettingRound == 'flop':
            self.runFlop(player, move,ifRaise)
            if len(self.allIn) >= (len(self.players)-1):
                division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
                self.distributeToWinners(division)
                self.gameOver = True
        elif self.bettingRound == 'turn':
            self.runTurn(player, move,ifRaise)
            if len(self.allIn) >= (len(self.players)-1):
                 division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
                 self.distributeToWinners(division)
                 self.gameOver = True
        elif self.bettingRound == 'river':
            self.runRiver(player, move,ifRaise)
        # elif self.bettingRound == "gameover":
        #     division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
        #     self.distributeToWinners(division)

    def runNextRounds(self,player, move,ifRaise):
        if player not in self.foldedPlayers:
            validAction = False
            while not validAction:
                if move == "fold":
                    self.handleFold(player)
                    validAction = True
                elif move == "call":
                    self.handleCall(player)
                    validAction = True
                elif move == "raise":
                    self.handleRaise(player, ifRaise)
                    validAction = True
                elif move == "check":
                    # If the player can check, update the counter and set the action as valid
                    validAction = True
                    self.counter += 1
        self.updateAllIn(player)

        # Update the current player position and move on to the next player's turn
        nextPlayerPosition = self.getNextPlayerPosition()
        self.updateCurrentPlayerPosition(nextPlayerPosition)

    def runPreflop(self, player, move, ifRaise=None):
        # If it is the preflop round
        if self.bettingRound == 'preflop':
            # Set the current bet based on the number of raises that have occurred so far
            if self.raiseCount == 0:
                self.currentBet = self.bigBlind
            else:
                # If raises have already occurred, set the current bet to the amount of the last raise
                if ifRaise is not None and self.lastPlayerToRaise != player:
                    #ifRaise = self.currentBet - self.betAmounts[player][self.bettingRound] + self.lastRaiseAmount
                    self.currentBet = ifRaise

            # Record the bet amount for the current player if they have not folded yet
            if player not in self.betAmounts:
                self.betAmounts[player][self.bettingRound] = 0

            # Handle the player's move
            if player not in self.foldedPlayers:
                validAction = False
                while not validAction:
                    if move == "fold":
                        self.handleFold(player)
                        validAction = True
                    elif move == "call":
                        self.handleCall(player)
                        validAction = True
                    elif move == "raise":
                        # If the player is the big blind or is raising, handle the raise
                        if (self.players.index(player) == self.bigBlindPosition) or (ifRaise is not None):
                            if self.raiseCount == 0 and (self.players.index(player) == self.smallBlindPosition):
                                # If it is the first betting round and the player is the small blind, add the small blind to the raise amount
                                amt = ifRaise + self.smallBlind
                                self.handleRaise(player, amt)
                            else:
                                # Otherwise, just handle the raise with the given raise amount
                                amt = ifRaise
                                self.handleRaise(player, amt)
                            validAction = True
                    elif move == "check":
                        # If the player can check, update the counter and set the action as valid
                        if self.currentBet != self.bigBlind:
                            if (self.players.index(player) == self.bigBlindPosition) or (self.players.index(player) == self.smallBlindPosition):
                                validAction = True
                                self.counter += 1
                        elif (self.currentBet == self.bigBlind) and (self.players.index(player) == self.bigBlindPosition):
                            validAction = True
                            self.counter += 1

            # Check if any players are all-in
            self.updateAllIn(player)

            # Update the current player position and move on to the next player's turn
            nextPlayerPosition = self.getNextPlayerPosition()
            self.updateCurrentPlayerPosition(nextPlayerPosition)

            if self.raiseCount > 0 and self.endBettingRound():
                self.bettingRound = "flop"
                self.currentPlayerPosition = self.dealerPosition
                nextPlayerPosition = self.getNextPlayerPosition()
                self.updateCurrentPlayerPosition(nextPlayerPosition)
                for player in self.betAmounts:
                    self.betAmounts[player][self.bettingRound] = 0
                self.currentBet = 0
                self.counter = 0
                self.flop()
            else:
            # If all players have acted, move on to the flop round
                if self.raiseCount == 0 and self.counter == len(self.players):
                    self.bettingRound = "flop"
                    self.currentPlayerPosition = self.dealerPosition
                    nextPlayerPosition = self.getNextPlayerPosition()
                    self.updateCurrentPlayerPosition(nextPlayerPosition)
                    for player in self.betAmounts:
                        self.betAmounts[player][self.bettingRound] = 0
                    self.currentBet = 0
                    self.counter = 0
                    self.flop()

    def runFlop(self,player, move,ifRaise):
        self.runNextRounds(player, move,ifRaise)
        if self.counter == len(self.players):
            self.bettingRound = "turn"
            self.currentPlayerPosition = self.dealerPosition
            nextPlayerPosition = self.getNextPlayerPosition()
            self.updateCurrentPlayerPosition(nextPlayerPosition)
            self.counter = 0
            self.turn()

    def runTurn(self,player, move,ifRaise):
        self.runNextRounds(player, move,ifRaise)
        if self.counter == len(self.players):
            self.bettingRound = "river"
            self.currentPlayerPosition = self.dealerPosition
            nextPlayerPosition = self.getNextPlayerPosition()
            self.updateCurrentPlayerPosition(nextPlayerPosition)
            self.counter = 0
            self.river()

    def runRiver(self,player, move,ifRaise):
        self.runNextRounds(player, move,ifRaise)
        if self.counter == len(self.players):
            # self.bettingRound = "gameover"
            division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
            self.distributeToWinners(division)
            self.gameOver = True
    
    def isLegalMove(self, player, move,raiseAmount = None):
        if player not in self.betAmounts:
            self.betAmounts[player][self.bettingRound] = 0
        if player in self.foldedPlayers:
            return False

        if move == "fold":
            return True

        if move == "call":
            if self.currentBet > self.betAmounts[player][self.bettingRound]:
                return True
            else:
                return False
     
        if move == "raise":
            if raiseAmount > self.stacks[player] or self.stacks[player] == 0: #if raise is grater than stack aamount or the person was already all in
                return False
            if round == "preflop":
                if self.raiseCount == 0:
                    if raiseAmount == self.currentBet:
                        return False
                    if (self.currentBet > self.betAmounts[player][self.bettingRound] or self.currentPlayerPosition == self.bigBlindPosition):
                        minRaise = self.currentBet - self.betAmounts[player][self.bettingRound] + self.bigBlind
                        maxRaise = self.stacks[player] + self.betAmounts[player][self.bettingRound]
                        if minRaise <= 0:
                            return False
                        if minRaise <= maxRaise:
                            return (player != self.smallBlindPosition or minRaise >= self.bigBlind)
                        else:
                            return False
                elif self.raiseCount > 0:
                    if self.stacks[player] - raiseAmount == 0: #player went all in
                        return True
                    if self.currentBet < raiseAmount < self.stacks[player]:
                        return True
            else:
                if raiseAmount >= self.bigBlind:
                    return True
                else:
                    return False
        if move == "check":
            if self.bettingRound == "preflop":
                if self.raiseCount == 0:
                    if self.players.index(player) == self.bigBlindPosition:
                        return True
                    else:
                        return False
                if self.raiseCount > 0:
                    if self.currentBet == self.betAmounts[player][self.bettingRound]:
                        return True
                else:
                    return False
            else:
               if self.currentBet == self.betAmounts[player][self.bettingRound]:
                        return True 

        return False

def onAppStart(app):
    app.cx = 200
    app.cy = 200
    app.colorFold = "orange"
    app.colorCall = "green"
    app.colorRaise = "green"
    app.colorCheck = "green"
    app.raiseBox = False
    app.raiseAmount = ''
    app.error = False
    app.roundCounter = 0
    app.game = TexasHoldem(players)
    
def newGame(app):
    if app.game.gameOver == True:
        app.roundCounter += 1
        app.game.nextRound()

def redrawAll(app):
    drawLabel(f"{app.game.currentPlayer}'s Turn",app.width/2,app.height/2,fill="black",size=16)
    drawOval(app.width/2,app.height/2,700,500,fill="green")
    # newimageWidth,newimageHeight = (app.image.width)+100,(app.image.height)+100
    # drawImage(app.image, (app.height/2), 500, align='center')
    drawOval(app.width/2,(app.height/2)-120,100,50,fill="pink")
    drawLabel(f'{app.game.potSize}',app.width/2,(app.height/2)-120, size=16)
    drawLabel(f"{app.game.currentPlayer}'s Turn",app.height/2,app.width/10,fill="black",size=24)
    # Draw player info
    for i in range(len(app.game.players)):
        length = 100
        width = 60
        centerX = app.width/2 + 300 * math.cos(math.pi/2 + i*math.pi/4)
        centerY = app.height/2 - 250 * math.sin(math.pi/2 + i*math.pi/4)
        drawRect(centerX - length/2, centerY - width/2, length, width, fill="red")
        drawLabel(app.game.players[i], centerX, centerY+10, fill="black", size=16)
        drawLabel(app.game.stacks[app.game.players[i]], centerX, centerY-15, fill="black", size=16)

        # Draw dealer, big blind, and small blind indicators
        if i == app.game.dealerPosition:
            drawCircle(centerX+50, centerY, 20, fill="white")
            drawLabel("D", centerX+50, centerY, size=16, bold=True)
        if i == app.game.bigBlindPosition:
            drawCircle(centerX+50, centerY, 20, fill="blue")
            drawLabel("BB", centerX+50, centerY, size=16, bold=True, fill="white")
        elif i == app.game.smallBlindPosition:
            drawCircle(centerX+50, centerY, 20, fill="grey")
            drawLabel("SB", centerX+50, centerY, size=16, bold=True, fill="black")
        drawLabel(app.game.holeCards[app.game.players[i]], centerX, centerY-80, size=16)
    if len(app.game.communityCards) > 0:
        drawLabel(app.game.communityCards, centerX, app.width/2, size=13)
    drawLabel(f'round: {app.game.bettingRound}', (app.height/2)+20, (app.width/2)+350, size=14)

    # Draw fold, call, check, and raise options
    centerX = app.width/2 + 100
    centerY = app.height/2 + 250
    drawRect(centerX+100,centerY+100,100,50,fill = app.colorFold)
    drawLabel("Fold",centerX+150,centerY+125,fill ="black",size=16,align="center",bold=True)
    drawRect(centerX-50,centerY+100,100,50,fill =app.colorCheck)
    drawLabel("check",centerX,centerY+125,fill ="black",size=16,align="center",bold=True)
    drawRect(centerX-250,centerY+100,100,50,fill =app.colorRaise)
    drawLabel("raise",centerX-200,centerY+125,fill ="black",size=16,align="center",bold=True)
    drawRect(centerX-400,centerY+100,100,50,fill =app.colorCall)
    drawLabel("call",centerX-350,centerY+125,fill ="black",size=16,align="center",bold=True)

    drawLabel(f'{app.game.currentBet}',500,50,size=25,bold=True,align="center")
    drawLabel(f'{app.roundCounter}',(app.height/2)+400, (app.width/2)-450, size=25)
    #Raise Amount box
    if app.raiseBox == True:
        drawRect(centerX-250,centerY+25,100,50,fill =None,border="black")
        drawLabel(f"Amount = {app.raiseAmount}",centerX-200,centerY+50)
    #error protection
    if app.error == True:
        drawLabel("Invalid",500,30,size=25,bold=True,align="center")

def onMousePress(app, mouseX, mouseY):
    newGame(app)
    app.cx = mouseX
    app.cy = mouseY
    centerX = app.width/2 + 100
    centerY = app.height/2 + 250
    if centerX-400 <= app.cx <= centerX-300 and centerY+100 <= app.cy <= centerY+150:
        app.colorCall = "lightGreen"
        player = app.game.currentPlayer
        move = "call"
        if app.game.isLegalMove(player, move):
            app.game.runBettingRound(player, move)
            app.error = False
        else:
            app.error = True
    elif centerX-250 <= app.cx <= centerX-150 and centerY+100 <= app.cy <= centerY+150:
        app.colorRaise = "lightGreen"
        app.raiseBox = True
        player = app.game.currentPlayer
        move = "raise"
    elif centerX-50 <= app.cx <= centerX+50 and centerY+100 <= app.cy <= centerY+150:
        app.colorCheck = "lightGreen"
        player = app.game.currentPlayer
        move = "check"
        if app.game.isLegalMove(player, move):
            app.game.runBettingRound(player, move)
            app.error = False
        else:
            app.error = True
    elif centerX+100 <= app.cx <= centerX+200 and centerY+100 <= app.cy <= centerY+150:
        app.colorFold = "purple"
        player = app.game.currentPlayer
        move = "fold"
        if app.game.isLegalMove(player, move):
            app.game.runBettingRound(player, move)
            app.error = False
        else:
            app.error = True

def onMouseRelease(app, mouseX, mouseY):
    app.colorFold = "orange"
    app.colorCall = "green"
    app.colorCheck = "green"
    app.colorRaise = "green"

def onKeyPress(app, key):
    newGame(app)
    player = app.game.currentPlayer
    move = "raise"
    if app.raiseBox == True:
        if key.isdigit():  # Check if the key is a digit
            app.raiseAmount += key
        elif key == 'backspace':  # Check if the key is the backspace key
            app.raiseAmount = app.raiseAmount[:-1]  # Remove the last character from the raise amount
        elif key == 'enter':  # Check if the key is the enter key
            amount = int(app.raiseAmount)  # Convert the raise amount to an integer
            if app.game.isLegalMove(player, move,amount):
                player = app.game.currentPlayer
                move = "raise"
                app.game.raiseOccurred = True
                app.game.runBettingRound(player, move, amount)
                app.raiseAmount = ''  # Reset the raise amount
                app.raiseBox = False
                app.error = False  
            else:
                app.error = True





players = {"A":100,"B":200,"C":300,"D":400,"E":500}
def main():
    runApp(width=1000,height=1000)
main()
