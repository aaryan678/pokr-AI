action = "raise 500"
s = action.split()
s = int(s[1])
print(type(s))