import random
import copy
import __deck__ as deck
import __checkWinner__ as winner



#to undertand what factors to be incuded in ai :https://www.primedope.com/sklansky-chubukov-rankings/ and https://www.primedope.com/pushbot-trainer/

class PokerAI:
    def __init__(self,potSize,holeCards,amountToCall,ranges,stack,round,flop=None,turn=None,river= None):
        self.potSize = potSize
        self.deck = deck.ShuffledDeck()
        self.holeCards = holeCards
        self.amountToCall = amountToCall
        self.remainingCards = None
        if flop != None:
            self.flop = flop
        if turn != None:
            self.turn = self.flop+turn
        if river != None:
            self.river = self.turn+river
        self.ranges = ranges
        self.allCombos = None
        self.round = round
        self.stack = stack
        # self.rangesOfPlayers = ranges.getAllPossibleHands()
        
    def bestMove(self, preFlopScore, myAiScore):
        decision = None
        toCall = self.amountToCall
        minRaise = toCall * 2
        maxRaise = self.stack
        potOdds = toCall / (self.potSize + toCall)
        handStrength = myAiScore / preFlopScore


        aggressiveFactor = 1.0 # adjust this based on the AI's personality
        riskFactor = 1.0 # adjust this based on the AI's personality
        
        if self.round == 'preflop':

            if 8.0 <= handStrength or myAiScore > 8.0 :
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//3
            elif 6.0 <= handStrength < 8.0 or myAiScore >= 5.0:
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//6
            elif 4.0 <= handStrength < 6.0:
                decision = 'call'
            elif 2.4 <= handStrength < 4.0:
                decision = 'fold'
            else:
                decision = 'fold'
        
        elif self.round == 'flop':
            if 8.0 <= handStrength or myAiScore > 8.0:
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//3
            elif 4.5 <= handStrength < 8.0:
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//6
            elif 2.5 <= handStrength < 4.5:
                decision = 'call'
            elif 0 <= handStrength < 2.5:
                decision = 'fold'
            else:
                decision = 'fold'
        
        elif self.round == 'turn':
            if 7.5 <= handStrength or myAiScore > 7.5:
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//3
            elif 6.0 <= handStrength < 7.5:
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//6
            elif 5.0 <= handStrength < 6.0:
                decision = 'call'
            elif 3.0<= handStrength < 5.0:
                decision = 'fold'
            else:
                decision = 'fold'
        
        elif self.round == 'river':
            if 8.0 <= handStrength or myAiScore > 8.0:
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//3
            elif 6.6 <= handStrength < 8.0:
                decision = 'raise'
                raiseAmount = (minRaise + int(aggressiveFactor * (maxRaise - minRaise)))//6
            elif 2.5 <= handStrength < 6.5:
                decision = 'call'
            elif 1.0 <= handStrength < 2.5:
                decision = 'fold'
            else:
                decision = 'fold'
            
        if decision == 'raise':
            return 'raise', raiseAmount
        else:
            return decision, 0

    def rangeManipulation(self):
        possibleHands = {}
        for player in self.ranges:
            if player not in possibleHands:
                possibleHands[player] = []
            for hand in self.ranges[player]:
                if self.ranges[player][hand] >= 0.15:
                    possibleHands[player].append(hand)

        allCombos = {}
        for name in possibleHands:
            combos = []
            for hand in possibleHands[name]:
                suits = ["Hearts", "Spades", "Diamonds", "Clubs"]
                Namerank1 = hand[0]
                Namerank2 = hand[1]
                rank1,rank2 = self.getProperNamedRank(Namerank1,Namerank2)
                

                if rank1 == rank2:
                    combos.append([f"{rank1} of {suits[0]}, {rank2} of {suits[1]}"])
                    combos.append([f"{rank1} of {suits[0]}, {rank2} of {suits[2]}"])
                    combos.append([f"{rank1} of {suits[0]}, {rank2} of {suits[3]}"])
                    combos.append([f"{rank1} of {suits[1]}, {rank2} of {suits[2]}"])
                    combos.append([f"{rank1} of {suits[1]}, {rank2} of {suits[3]}"])
                    combos.append([f"{rank1} of {suits[2]}, {rank2} of {suits[3]}"])
                else:
                    combos.append([f"{rank1} of {suits[0]}, {rank2} of {suits[1]}"])
                    combos.append([f"{rank1} of {suits[0]}, {rank2} of {suits[2]}"])
                    combos.append([f"{rank1} of {suits[0]}, {rank2} of {suits[3]}"])
                    combos.append([f"{rank1} of {suits[1]}, {rank2} of {suits[0]}"])
                    combos.append([f"{rank1} of {suits[1]}, {rank2} of {suits[2]}"])
                    combos.append([f"{rank1} of {suits[1]}, {rank2} of {suits[3]}"])
                    combos.append([f"{rank1} of {suits[2]}, {rank2} of {suits[0]}"])
                    combos.append([f"{rank1} of {suits[2]}, {rank2} of {suits[1]}"])
                    combos.append([f"{rank1} of {suits[2]}, {rank2} of {suits[3]}"])
                    combos.append([f"{rank1} of {suits[3]}, {rank2} of {suits[0]}"])
                    combos.append([f"{rank1} of {suits[3]}, {rank2} of {suits[1]}"])
                    combos.append([f"{rank1} of {suits[3]}, {rank2} of {suits[2]}"])
            allCombos[name] = combos
        self.allCombos = allCombos

    def getProperNamedRank(self, Namerank1, Namerank2):
        rank_names = {
            '2': 'Deuce',
            '3': 'Three',
            '4': 'Four',
            '5': 'Five',
            '6': 'Six',
            '7': 'Seven',
            '8': 'Eight',
            '9': 'Nine',
            'T': 'Ten',
            'J': 'Jack',
            'Q': 'Queen',
            'K': 'King',
            'A': 'Ace'
        }

        Namerank1 = rank_names[Namerank1]
        Namerank2 = rank_names[Namerank2]

        return Namerank1, Namerank2
   
    def getRemainingDeck(self, deck, holeCards):
        self.remainingCards = copy.deepcopy(deck)
        holeCardsObjects = []
        for card in holeCards:
            # card_str = str(card[0]) + " of " + str(card[1])
            for c in self.remainingCards:
                if str(c) == card:
                    holeCardsObjects.append(c)
                    self.remainingCards.remove(c)
                    break
        return self.remainingCards

    #gets the card ranks and the suits
    def getHandScore(self,holeCards):
        cards = []
        suits = []
        for hands in holeCards:
            hands = str(hands)
            indexSpace = hands.index(" ")
            indexOf = hands.index("of")
            card = hands[0:indexSpace]
            suit = hands[indexOf+3:]
            cards.append(card)
            suits.append(suit)
        rank = winner.rankCard(cards)
        return(rank,suits)
    
    def simulateGame(self,holeCards):
        self.remainingCards = self.getRemainingDeck(self.deck, holeCards)
        self.rangeManipulation()
        Move = None
        if self.round == "preflop":
            preFlopScore = self.runMonteCarloPreFlop()
            myAiScorePf =  self.getAiSelfPlayersScore(holeCards)
            Move = self.bestMove(preFlopScore,myAiScorePf)
        if self.round == "flop":
            flopScore = self.runMonteCarloFlop()
            myAiScoreF =  self.getAiSelfPlayersScore(holeCards,self.flop)
            Move = self.bestMove(flopScore,myAiScoreF)
        if self.round == "turn":
            turnScore = self.runMonteCarloTurn()
            myAiScoreT =  self.getAiSelfPlayersScore(holeCards,self.turn)
            Move = self.bestMove(turnScore,myAiScoreT)
        if self.round == "river":
            riverpScore = self.runMonteCarloRiver()
            myAiScoreR =  self.getAiSelfPlayersScore(holeCards,self.river)
            Move = self.bestMove(riverpScore,myAiScoreR)
        return(Move)

    def runMonteCarloPreFlop(self, iterations=10000):
        finalTotalCounts = []
        for key,value in self.allCombos.items():
            validHands = self.allCombos[key]
            counts = {}
            self.remainingCards = self.getRemainingDeck(self.deck,self.holeCards)
            random.shuffle(self.remainingCards)
            for i in range (iterations):
                hand = random.choice(validHands)

                board = self.remainingCards[:5]

                score = winner.scoreHand(hand,board)
                counts[i] = score

            totalCount = sum(counts.values())
            finalTotalCounts.append(totalCount//iterations)
        return(sum(finalTotalCounts)/len(finalTotalCounts))

    def runMonteCarloFlop(self,iterations=1000):
        finalTotalCounts = []
        for key,value in self.allCombos.items():
            validHands = self.allCombos[key]
            counts = {}
            self.remainingCards = self.getRemainingDeck(self.remainingCards,self.flop)
            random.shuffle(self.remainingCards)
            for i in range(iterations):
                random.shuffle(self.remainingCards)
                hand = random.choice(validHands)
                board = self.flop+self.remainingCards[:2]
                score = winner.scoreHand(hand,board)
                counts[i] = score
            totalCount = sum(counts.values())
            finalTotalCounts.append(totalCount//iterations)
        return(sum(finalTotalCounts)/len(finalTotalCounts))
        
    def runMonteCarloTurn(self,iterations=1000):
        finalTotalCounts = []
        for key,value in self.allCombos.items():
            validHands = self.allCombos[key]
            counts = {}
            self.remainingCards = self.getRemainingDeck(self.remainingCards,self.flop)
            random.shuffle(self.remainingCards)
            for i in range(iterations):
                random.shuffle(self.remainingCards)
                hand = random.choice(validHands)
                board = self.turn+self.remainingCards[:1]
                score = winner.scoreHand(hand,board)
                counts[i] = score
            totalCount = sum(counts.values())
            finalTotalCounts.append(totalCount//iterations)
        return(sum(finalTotalCounts)/len(finalTotalCounts))
    
    def runMonteCarloRiver(self, iterations=1000):
        finalTotalCounts = []
        for key,value in self.allCombos.items():
            validHands = self.allCombos[key]
            counts = {}
            self.remainingCards = self.getRemainingDeck(self.deck,self.holeCards)
            random.shuffle(self.remainingCards)
            for i in range (iterations):
                hand = random.choice(validHands)
                board = self.river
                score = winner.scoreHand(hand,board)
                counts[i] = score
            totalCount = sum(counts.values())
            finalTotalCounts.append(totalCount//iterations)
        return(sum(finalTotalCounts)/len(finalTotalCounts))
    
    def potOddsCalculator(self):
        return (self.amountToCall/(self.potSize+self.amountToCall))*100
    
    def getAiSelfPlayersScore(self,holeCards,flop = None,turn=None,river=None):
        counts = {}
        iterations = 10000
        # self.remainingCards = self.getRemainingDeck(self.remainingCards,self.turn)
        random.shuffle(self.remainingCards)
        for i in range(iterations):
            random.shuffle(self.remainingCards)
            hand = holeCards
            if flop == None and turn == None and river == None:
                board = self.remainingCards[:5]
            elif flop != None:
                board = self.flop+self.remainingCards[:2]
            elif turn != None:
                board = self.turn+self.remainingCards[:1]
            elif river != None:
                board = self.river
            score = winner.scoreHand(hand,board)
            counts[i] = score

        totalCount = sum(counts.values())
        return totalCount//iterations

    def potOdds(self):
        potOdd = self.potOddsCalculator()
        OtherPlayerScore = self.getOtherPlayersScore()
        aiScore = self.runMonteCarloPreFlop(self.holeCards)
        equity = (aiScore-OtherPlayerScore)
        percentageEquity = (equity/aiScore)*100
        
        return percentageEquity
