#basic poker theory and range calcultions used from/taken help to understand from website:https://upswingpoker.com/pot-odds-step-by-step/
class PokerRange:
    def __init__(self, position, stacks, strategies,totalRaiseCounts,players,foldedPlayers,bigBlind):
        self.position = position
        self.stackSize = stacks
        self.strategies = strategies
        self.totalRaiseCounts = totalRaiseCounts
        self.players = players
        self.foldedPlayers = foldedPlayers
        self.bigBlind = bigBlind
        self.getAllPossibleHands()

    def getPosition(self,playerStyle):
        if playerStyle == "Dealer":
            return 1.2
        elif playerStyle == "Late":
            return 1.1
        elif playerStyle == "Middle":
            return 0.95
        elif playerStyle == "Blind":
            return 0.8

    def getStackSize(self,stack):
        Bb = stack/self.bigBlind
        if Bb > 50:
            return 1.2
        elif 20 < Bb < 50:
            return 1.0
        else:
            return 0.7

    def getOpponentsStyle(self,playerAttitude):

        if playerAttitude == 'Very Aggressive':
            return 1.2
        elif playerAttitude == 'Aggressive':
            return 1.1
        elif playerAttitude == 'Semi-Aggressive':
            return 1.0
        elif playerAttitude == 'Passive':
            return 0.8
        elif playerAttitude == 'Conservative':
            return 0.7
        elif playerAttitude == 'Very Passive':
            return 0.6

    def getAllPossibleHands(self):
        cumulativeDict = {}
        for player in self.players:
            if player not in self.foldedPlayers:
                suits = ["Hearts", "Spades", "Diamonds", "Clubs"]
                values = {
                    "2": 2,
                    "3": 3,
                    "4": 4,
                    "5": 5,
                    "6": 6,
                    "7": 7,
                    "8": 8,
                    "9": 9,
                    "T": 10,
                    "J": 11,
                    "Q": 12,
                    "K": 13,
                    "A": 14
                }

                # Generate all possible combinations of starting hands
                startingHands = []+['AA']
                for i in range(len(values)):
                    for j in range(i+1, len(values)):
                        for s1 in suits:
                            for s2 in suits:
                                if s1 != s2:
                                    rank1 = list(values.keys())[list(values.values()).index(i+2)]
                                    rank2 = list(values.keys())[list(values.values()).index(j+2)]
                                    startingHands.append(rank2 + rank1 + "s")
                                    startingHands.append(rank2 + rank1 + "o")
                                    if rank1+rank1 not in startingHands:
                                        startingHands.append(rank1 + rank1)

                # Initialize the range dictionary with weights for all possible hands
                rangeDict = {}
                for hand in startingHands:
                    rank1 = values[hand[0]]
                    rank2 = values[hand[1]]
                    # playerIndex = self.players.index(player)
                    playerPosition = self.position[player]
                    playerStack = self.stackSize[player]
                    playerAttitude = self.strategies[player]

                    weightPos = self.getPosition(playerPosition)
                    weightStack = self.getStackSize(playerStack)
                    weightOpp = self.getOpponentsStyle(playerAttitude)

                    if rank1 == rank2:
                        score = round(weightPos * weightStack * weightOpp * ((rank1*2)+(rank1**1)),2)
                    else:
                        suited = hand[2] == "s"
                        gap = abs(rank1 - rank2) - 1
                        straightDraw = (gap == 3 or gap == 2)
                        flushDraw = suited and gap <= 1
                        if straightDraw or flushDraw:
                            if suited:
                                score = round(weightPos * weightStack * weightOpp * (rank1 + rank2 + (gap / 2) + (suited / 2)), 2)
                            else:
                                score = round(weightPos * weightStack * weightOpp * (rank1 + rank2 + (gap / 2)), 2)
                        elif gap <= 2:
                            if suited:
                                score = round(weightPos * weightStack * weightOpp * (rank1 + rank2 - gap / 2 + (suited / 4)), 2)
                            else:
                                score = round(weightPos * weightStack * weightOpp * (rank1 + rank2 - gap / 2), 2)
                        else:
                            if suited:
                                score = round(weightPos * weightStack * weightOpp * (rank1 + rank2 - gap / 2 - (suited / 4)), 2)
                            else:
                                score = round(weightPos * weightStack * weightOpp * (rank1 + rank2 - gap / 2), 2)

                        if rank1 < 11 and rank2 < 11:
                            score -= (10 - (rank1 + rank2) / 2) / 2
                            if suited:
                                score += 0.5
                        elif rank1 == 11 and rank2 == 12 or rank1 == 12 and rank2 == 11:
                            score += 0.5
                        elif rank1 == 14 or rank2 == 14:
                            score += 1 
                    score = (score/100)
                    rangeDict[hand] = round(score, 2)
                cumulativeDict[player] = rangeDict
        return(cumulativeDict) 

