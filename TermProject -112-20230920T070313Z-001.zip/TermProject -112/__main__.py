import __deck__ as deck
import __checkWinner__ as winner
from __pokerRanges__ import PokerRange
from __PokerAI__ import PokerAI
from cmu_graphics import *
import math
import string
import time
#This is the TexasHoldem class, defines the game and all its features
class TexasHoldem: 
    def __init__(self, players):
        self.deck = []
        self.stacks = players # store the player stacks in a dictionary
        self.players = list(self.stacks.keys()) # convert dictionary keys to a list of players
        self.dealerPosition = 0
        self.smallBlindPosition = 0
        self.bigBlindPosition = 0
        self.smallBlind = 10
        self.bigBlind = 20
        self.potSize = 0
        self.communityCards = []
        self.holeCards = {}
        self.bettingRound = ''
        self.betAmounts = {}
        self.counter = 0
        self.currentBet = self.bigBlind 
        self.foldedPlayers = set()
        self.foldedPlayerIndex =[]
        self.winningHand = []
        self.currentPlayerPosition = (self.dealerPosition - 4) % len(self.players)
        self.currentPlayer = self.players[self.currentPlayerPosition]
        self.raiseOccurred = False
        self.raiseCount = 0
        self.nextPlayerIndex = (self.currentPlayerPosition - 1)
        self.allIn = []
        self.sidePot = dict()
        self.lastRaiseAmount = 0
        self.gameOver = False
        self.amountToCall = self.bigBlind
        self.timeLimit = 30
        self.allPlayerActed = False
#------------------------------------------------------------------------------ Fo AI only
        self.positions = None
        self.strategies = None
        self.totalRaiseCounts = {}
        for player in self.players:
            self.totalRaiseCounts[player] = {'call': 1, 'check': 1, 'raise': 1}
        self.showBestMove = True    
#------------------------------------------------------------------------------ Fo AI only

        self.turnStartTime = None
        self.turnPlayer = None
        self.bettingTimeLimit = 20
        self.elapsedTime = None


        self.roundCounter = 0
        self.initializeGame()

#gets position of the players for the AI
    def getPositions(self):
        num_players = len(self.players)
        # Assign positions based on player index
        positions = {}
        for i in range(num_players):
            position_index = (i - self.dealerPosition) % num_players
            if position_index == 0:
                positions[self.players[i]] = "Dealer"
            elif position_index == -1 or position_index == num_players - 2:
                positions[self.players[i]] = "Blind"
            elif position_index == 2 or position_index == num_players - 2:
                positions[self.players[i]] = "Middle"
            else:
                positions[self.players[i]] = "Late"

        self.positions = positions

#gets stratergy of the players for the AI
    def describeStrategy(self):
        strategies = {}
        for playerId, counts in self.totalRaiseCounts.items():
            totalMoves = sum(counts.values())
            callPercentage = counts['call'] / totalMoves
            checkPercentage = counts['check'] / totalMoves
            raisePercentage = counts['raise'] / totalMoves
            position = self.positions[playerId]
            chips = self.stacks[playerId]
            Bb = chips/self.bigBlind
            if position == 'Dealer':
                if raisePercentage > 0.3 and Bb > 50:
                    strategies[playerId] = 'Very Aggressive'
                elif raisePercentage > 0.2 and 20 < Bb < 50:
                    strategies[playerId] = 'Aggressive'
                elif raisePercentage > 0.1:
                    strategies[playerId] = 'Semi-Aggressive'
                elif checkPercentage > 0.6:
                    strategies[playerId] = 'Very Passive'
                elif callPercentage > 0.5:
                    strategies[playerId] = 'Passive'
                else:
                    strategies[playerId] = 'Conservative'

            elif position == 'Blind':
                if raisePercentage > 0.4 and Bb > 30:
                    strategies[playerId] = 'Very Aggressive'
                elif raisePercentage > 0.3 and 0 < Bb < 30:
                    strategies[playerId] = 'Aggressive'
                elif raisePercentage > 0.2:
                    strategies[playerId] = 'Semi-Aggressive'
                elif checkPercentage > 0.6:
                    strategies[playerId] = 'Very Passive'
                elif callPercentage > 0.5:
                    strategies[playerId] = 'Passive'
                else:
                    strategies[playerId] = 'Conservative'

            elif position == 'Late':
                if raisePercentage > 0.3 and Bb > 50:
                    strategies[playerId] = 'Very Aggressive'
                elif raisePercentage > 0.2 and 10 < Bb < 50:
                    strategies[playerId] = 'Aggressive'
                elif raisePercentage > 0.1:
                    strategies[playerId] = 'Semi-Aggressive'
                elif checkPercentage > 0.6:
                    strategies[playerId] = 'Very Passive'
                elif callPercentage > 0.5:
                    strategies[playerId] = 'Passive'
                else:
                    strategies[playerId] = 'Conservative'

            else: # middle position
                if raisePercentage > 0.2:
                    strategies[playerId] = 'Aggressive'
                elif raisePercentage > 0.1:
                    strategies[playerId] = 'Semi-Aggressive'
                elif checkPercentage > 0.6:
                    strategies[playerId] = 'Very Passive'
                elif callPercentage > 0.5:
                    strategies[playerId] = 'Passive'
                else:
                    strategies[playerId] = 'Conservative'

        self.strategies = strategies

#initializes new round
    def newRound(self):
        if self.gameOver == True:
            keysToRemove = []
            for key, value in self.stacks.items():
                if value == 0:
                    keysToRemove.append(key)
            for key in keysToRemove:
                del self.stacks[key]
                self.players.remove(key)
                del self.totalRaiseCounts[key]
            self.deck = []
            self.foldedPlayers = set()
            self.foldedPlayerIndex =[]
            self.allIn = []
            self.dealerPosition -= len(self.players)
            self.potSize = 0
            self.communityCards = []
            self.holeCards = {}
            self.bettingRound = ''
            self.betAmounts = {}
            self.counter = 0
            self.currentBet = self.bigBlind 
            self.winningHand = []
            self.currentPlayerPosition = (self.dealerPosition - 4) % len(self.players)
            self.currentPlayer = self.players[self.currentPlayerPosition]
            self.raiseOccurred = False
            self.raiseCount = 0
            self.nextPlayerIndex = (self.currentPlayerPosition - 1)
            self.sidePot = dict()
            self.lastRaiseAmount = 0
            self.amountToCall = self.bigBlind
            self.roundCounter += 1
            self.initializeGame()
            self.gameOver = False
#gets best move from the AI file
    def getBestMove(self):
        player = self.currentPlayer
        if self.showBestMove == True:
            AiRange = PokerRange(self.positions, self.stacks, self.strategies,self.totalRaiseCounts,self.players,self.foldedPlayers,self.bigBlind)
            playerRanges = (AiRange.getAllPossibleHands())
            holeCards = self.holeCards[player]
            stack = self.stacks[player]
            if self.bettingRound == "preflop":
                playerMove = PokerAI(self.potSize,holeCards,self.amountToCall,playerRanges,stack,self.bettingRound)
                return(playerMove.simulateGame(holeCards))
            elif self.bettingRound == "flop":
                playerMove = PokerAI(self.potSize,holeCards,self.amountToCall,playerRanges,stack,self.bettingRound,self.communityCards[:3])
                return(playerMove.simulateGame(holeCards))
            elif self.bettingRound == "turn":
                playerMove = PokerAI(self.potSize,holeCards,self.amountToCall,playerRanges,stack,self.bettingRound,self.communityCards[:3],[self.communityCards[3]])
                return(playerMove.simulateGame(holeCards))
            elif self.bettingRound == "river":
                playerMove = PokerAI(self.potSize,holeCards,self.amountToCall,playerRanges,stack,self.bettingRound,self.communityCards[:3],[self.communityCards[3]],self.communityCards[-5:])
                return(playerMove.simulateGame(holeCards))
#gets PotOdds for player
    def potOdds(self):
        player = self.currentPlayer
        totalPot = self.potSize
        max = 0
        playerValue = self.betAmounts[player][self.bettingRound]
        for key in self.betAmounts:
            if self.betAmounts[key][self.bettingRound] >= max:
                max = self.betAmounts[key][self.bettingRound]
        amountToCall = abs(max - playerValue)
        # Calculate the pot odds
        potOdds = rounded((amountToCall / totalPot)*100) if amountToCall != 0 else "check"
        return potOdds

    def aiRangeFunction(self):
        calculator = PokerRange(self.positions, self.stacks, self.strategies, self.totalRaiseCounts, self.players, self.foldedPlayers, self.bigBlind)
        (calculator.getAllPossibleHands())
#initialize the game
    def initializeGame(self):
        self.deck = deck.ShuffledDeck()
        self.dealHoleCards()
        self.setDealerPosition()
        self.setBetAmounts()
        self.setBlinds()
        self.getPositions()
        self.describeStrategy()
        self.bettingRound = 'preflop'
#deal cards to player
    def dealHoleCards(self):
        for player in self.players:
            self.holeCards[player] = [self.deck.pop(0), self.deck.pop(0)]
#set the dealer position based on the round
    def setDealerPosition(self):
        self.dealerPosition = (self.dealerPosition -1 ) % len(self.players)

    def setBetAmounts(self):
        roundList = ["preflop", "flop", "turn", "river"]
        for player in self.players:
            self.betAmounts[player] = {}
            for round in roundList:
                self.betAmounts[player][round] = 0
#set the Blind position based on the round        
    def setBlinds(self):
        self.smallBlindPosition = (self.dealerPosition -1 ) % len(self.players)
        self.bigBlindPosition = (self.dealerPosition - 2) % len(self.players)

        self.betAmounts[self.players[self.smallBlindPosition]]["preflop"] = self.smallBlind
        self.betAmounts[self.players[self.bigBlindPosition]]["preflop"] = self.bigBlind

        self.stacks[self.players[self.smallBlindPosition]] -= self.smallBlind
        self.stacks[self.players[self.bigBlindPosition]] -= self.bigBlind
        
        self.potSize = self.smallBlind + self.bigBlind

#eun flop/turn/river

    def flop(self):
        self.deck.pop(0)
        self.communityCards += [self.deck.pop(0), self.deck.pop(0),self.deck.pop(0)]

    def turn(self):
        self.deck.pop(0)
        self.communityCards += [self.deck.pop(0)]

    def river(self):
        self.deck.pop(0)
        self.communityCards += [self.deck.pop(0)]

#handle player moves/check/fold/call/raise

    def handleFold(self, player):
        # self.counter += 1
        self.foldedPlayers.add(player)
        self.foldedPlayerIndex.append(self.players.index(player)) 
        self.betAmounts.pop(player)

    def handleCall(self, player):
        amountToCall = self.currentBet - self.betAmounts[player][self.bettingRound] # subtracting the previous bet amount
        self.amountToCall = amountToCall
        if amountToCall > self.stacks[player]:
            amountToCall = self.stacks[player]
        self.stacks[player] -= amountToCall
        self.betAmounts[player][self.bettingRound] += amountToCall
        self.potSize += amountToCall
        self.counter += 1
        if player in self.totalRaiseCounts:
            self.totalRaiseCounts[player]["call"] +=1 
        else:
            self.totalRaiseCounts[player]["call"] = 1

    def handleRaise(self, player, ifRaise):
        # if self.raiseCount == 0:
        #     amountToRaise = ifRaise #- self.smallBlind
        # else:
        amountToRaise = ifRaise
        if amountToRaise > self.stacks[player]:
            amountToRaise = self.stacks[player]
        self.stacks[player] -= amountToRaise
        self.currentBet = amountToRaise #abs((amountToRaise + self.lastRaiseAmount) - self.betAmounts[player][self.bettingRound])
        self.betAmounts[player][self.bettingRound] += abs(amountToRaise-self.betAmounts[player][self.bettingRound])
        self.potSize += amountToRaise
        self.lastPlayerToRaise = player
        self.raiseOccurred = True
        self.counter  = 0
        self.raiseCount += 1
        if player in self.totalRaiseCounts:
            self.totalRaiseCounts[player]["raise"] +=1 
        else:
            self.totalRaiseCounts[player]["raise"] = 1
        self.lastRaiseAmount = amountToRaise
        
    def handleCheck(self, player):
        if self.currentBet != self.bigBlind:
            if (self.players.index(player) == self.bigBlindPosition) or (self.players.index(player) == self.smallBlindPosition):
                self.counter += 1
        elif (self.currentBet == self.bigBlind) and (self.players.index(player) == self.bigBlindPosition):
            self.counter += 1
        if player in self.totalRaiseCounts:
            self.totalRaiseCounts[player]['check'] +=1 
        else:
            self.totalRaiseCounts[player]['check'] = 1


#functions that run the game :
    def endBettingRound(self):
        round = self.bettingRound
        betAmount = set()
        for player in self.players:
            if player not in self.foldedPlayers:
                betAmount.add(self.betAmounts[player][round])
        print(self.betAmounts)
        
        allInPlayers = [player for player in self.players if self.stacks[player] == 0]
        if allInPlayers:
            lastBet = max(betAmount)
            if lastBet in betAmount and len(betAmount) == 1:
                return True
            elif lastBet in betAmount:
                return False
            else:
                return True
        else:
            if len(betAmount) == 1:
                return True
            else:
                return False

    def updateAllIn(self,player):
        if self.stacks[player] == 0:
            self.allIn.append(self.currentPlayerPosition)
        if self.stacks[player] == 0:
            self.sidePot[player] = self.potSize

    def getNextPlayerPosition(self):
        nextPlayerPosition = (self.currentPlayerPosition - 1) % len(self.players)
        for i in range(len(self.players)-1):
            if nextPlayerPosition in self.allIn+self.foldedPlayerIndex:
                nextPlayerPosition = (nextPlayerPosition - 1) % len(self.players)
            else:
                break
        else:
            nextPlayerPosition = None
        return nextPlayerPosition

    def updateCurrentPlayerPosition(self, nextPlayerPosition):
        if nextPlayerPosition is None:
            self.currentPlayerPosition = self.currentPlayerPosition
        else:
            self.currentPlayerPosition = nextPlayerPosition

            self.currentPlayer = self.players[self.currentPlayerPosition]

#distribute to winners the amount also splits the pot incase and returns according to that
    def distributeToWinners(self,division):
        for player in division:
            self.stacks[player] += division[player]

    def runBettingRound(self, player, move, ifRaise=None): 
        # self.startTimer()
        if self.bettingRound == 'preflop':
            self.runPreflop(player, move, ifRaise)
            if len(self.players) - len(self.allIn) - len(self.foldedPlayers) == 1  and self.counter == (len(self.players)-len(self.foldedPlayers))-1:
                self.flop()
                self.turn()
                self.river()
                if len(self.communityCards) > 5:
                    self.communityCards = self.communityCards[:5]
                division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
                self.distributeToWinners(division)
                self.gameOver = True
        elif self.bettingRound == 'flop':
            self.runFlop(player, move,ifRaise)
            if len(self.players) - len(self.allIn) - len(self.foldedPlayers) == 1  and self.counter == (len(self.players)-len(self.foldedPlayers))-1:
                self.turn()
                if len(self.communityCards) > 5:
                    self.communityCards = self.communityCards[:5]
                division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
                self.distributeToWinners(division)
                self.gameOver = True
        elif self.bettingRound == 'turn':
            self.runTurn(player, move,ifRaise)
            if len(self.players) - len(self.allIn) - len(self.foldedPlayers) == 1 and self.counter == (len(self.players)-len(self.foldedPlayers))-1:
                self.river()
                if len(self.communityCards) > 5:
                    self.communityCards = self.communityCards[:5]
                division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
                self.distributeToWinners(division)
                self.gameOver = True
        elif self.bettingRound == 'river':
            self.runRiver(player, move,ifRaise)

    def runNextRounds(self,player, move,ifRaise):
        if player not in self.foldedPlayers:
            validAction = False
            while not validAction:
                if move == "fold":
                    self.handleFold(player)
                    validAction = True
                elif move == "call":
                    self.handleCall(player)
                    validAction = True
                elif move == "raise":
                    self.handleRaise(player, ifRaise)
                    validAction = True
                elif move == "check":
                    # If the player can check, update the counter and set the action as valid
                    validAction = True
                    self.counter += 1
                    if player in self.totalRaiseCounts:
                        self.totalRaiseCounts[player]['check'] +=1 
                    else:
                        self.totalRaiseCounts[player]['check'] = 1
        self.updateAllIn(player)

        # Update the current player position and move on to the next player's turn
        nextPlayerPosition = self.getNextPlayerPosition()
        self.updateCurrentPlayerPosition(nextPlayerPosition)

    def runPreflop(self, player, move, ifRaise=None):
        # If it is the preflop round
        if self.bettingRound == 'preflop':
            # Set the current bet based on the number of raises that have occurred so far
            if self.raiseCount == 0:
                self.currentBet = self.bigBlind
            else:
                # If raises have already occurred, set the current bet to the amount of the last raise
                if ifRaise is not None and self.lastPlayerToRaise != player:
                    #ifRaise = self.currentBet - self.betAmounts[player][self.bettingRound] + self.lastRaiseAmount
                    self.currentBet = ifRaise

            # Record the bet amount for the current player if they have not folded yet
            if player not in self.betAmounts:
                self.betAmounts[player][self.bettingRound] = 0

            # Handle the player's move
            if player not in self.foldedPlayers:
                validAction = False
                while not validAction:
                    if move == "fold":
                        self.handleFold(player)
                        validAction = True

                    elif move == "call":
                        self.handleCall(player)
                        validAction = True

                    elif move == "raise":
                        # If the player is the big blind or is raising, handle the raise
                        if (self.players.index(player) == self.bigBlindPosition) or (ifRaise is not None):
                            if self.raiseCount == 0 and (self.players.index(player) == self.smallBlindPosition):
                                # If it is the first betting round and the player is the small blind, add the small blind to the raise amount
                                amt = ifRaise + self.smallBlind
                                self.handleRaise(player, amt)
                                
                            else:
                                # Otherwise, just handle the raise with the given raise amount
                                amt = ifRaise
                                self.handleRaise(player, amt)
                            validAction = True

                    elif move == "check":
                        # If the player can check, update the counter and set the action as valid
                        if self.currentBet != self.bigBlind:
                            if (self.players.index(player) == self.bigBlindPosition) or (self.players.index(player) == self.smallBlindPosition):
                                validAction = True
                                self.counter += 1
                        elif (self.currentBet == self.bigBlind) and (self.players.index(player) == self.bigBlindPosition):
                            validAction = True
                            self.counter += 1

                        if player in self.totalRaiseCounts:
                            self.totalRaiseCounts[player]['check'] +=1 
                        else:
                            self.totalRaiseCounts[player]['check'] = 1

            # Check if any players are all-in
            self.updateAllIn(player)

            # Update the current player position and move on to the next player's turn
            nextPlayerPosition = self.getNextPlayerPosition()
            self.updateCurrentPlayerPosition(nextPlayerPosition)

            if self.raiseCount > 0 and self.endBettingRound():
                self.bettingRound = "flop"
                self.raiseCount = 0
                self.currentPlayerPosition = self.dealerPosition
                nextPlayerPosition = self.getNextPlayerPosition()
                self.updateCurrentPlayerPosition(nextPlayerPosition)
                for player in self.betAmounts:
                    self.betAmounts[player][self.bettingRound] = 0
                self.currentBet = 0
                self.counter = 0
                self.flop()
            else:
            # If all players have acted, move on to the flop round
                if self.counter == (len(self.players)-len(self.foldedPlayers)):
                    self.bettingRound = "flop"
                    self.raiseCount = 0
                    self.currentPlayerPosition = self.dealerPosition
                    nextPlayerPosition = self.getNextPlayerPosition()
                    self.updateCurrentPlayerPosition(nextPlayerPosition)
                    for player in self.betAmounts:
                        self.betAmounts[player][self.bettingRound] = 0
                    self.currentBet = 0
                    self.counter = 0
                    self.flop()

    def runFlop(self,player, move,ifRaise):
        # if self.showBestMove == True:
        #     AiRange = PokerRange(self.positions, self.stacks, self.strategies,self.totalRaiseCounts,self.players,self.foldedPlayers,self.bigBlind)
        #     playerRanges = (AiRange.getAllPossibleHands())
        #     holeCards = self.holeCards[player]
        #     stack = self.stacks[player]
        #     playerMove = PokerAI(self.potSize,holeCards,self.amountToCall,playerRanges,stack,self.bettingRound,self.communityCards[:3])
        #     print(playerMove)
        #     print(playerMove.simulateGame(holeCards))

        self.runNextRounds(player, move,ifRaise)
        if self.raiseCount > 0 and self.endBettingRound():
            self.bettingRound = "turn"
            self.raiseCount = 0
            self.currentPlayerPosition = self.dealerPosition
            nextPlayerPosition = self.getNextPlayerPosition()
            self.updateCurrentPlayerPosition(nextPlayerPosition)
            self.currentBet = 0
            self.counter = 0
            self.turn()
        else:
            if self.counter == (len(self.players)-len(self.foldedPlayers)):
                self.bettingRound = "turn"
                self.raiseCount = 0
                self.currentPlayerPosition = self.dealerPosition
                nextPlayerPosition = self.getNextPlayerPosition()
                self.updateCurrentPlayerPosition(nextPlayerPosition)
                self.currentBet = 0
                self.counter = 0
                self.turn()

    def runTurn(self,player, move,ifRaise):

        self.runNextRounds(player, move,ifRaise)
        if self.raiseCount > 0 and self.endBettingRound():
            self.bettingRound = "river"
            self.raiseCount = 0
            self.currentPlayerPosition = self.dealerPosition
            nextPlayerPosition = self.getNextPlayerPosition()
            self.updateCurrentPlayerPosition(nextPlayerPosition)
            self.currentBet = 0
            self.counter = 0
            self.turn()
        else:
            if self.counter == (len(self.players)-len(self.foldedPlayers)):
                self.bettingRound = "river"
                self.raiseCount = 0
                self.currentPlayerPosition = self.dealerPosition
                nextPlayerPosition = self.getNextPlayerPosition()
                self.updateCurrentPlayerPosition(nextPlayerPosition)
                self.currentBet = 0
                self.counter = 0
                self.turn()

    def runRiver(self,player, move,ifRaise):

        self.runNextRounds(player, move,ifRaise)
        if self.raiseCount > 0 and self.endBettingRound():
            # self.bettingRound = "gameover"
            division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
            self.distributeToWinners(division)
            self.gameOver = True
        else:
            if self.counter == (len(self.players)-len(self.foldedPlayers)):
                # self.bettingRound = "gameover"
                division = winner.winner(self.holeCards,self.communityCards,self.sidePot,self.potSize,self.foldedPlayers)
                self.distributeToWinners(division)
                self.gameOver = True

#check legality of move
    def isLegalMove(self, player, move,raiseAmount = None):
        if player not in self.betAmounts:
            self.betAmounts[player][self.bettingRound] = 0
        if player in self.foldedPlayers:
            return False
        if move == "fold":
            return True
        if move == "call":
            if self.currentBet > self.betAmounts[player][self.bettingRound]:
                return True
            else:
                return False
        if move == "raise":
            if raiseAmount > self.stacks[player] or self.stacks[player] == 0: #if raise is grater than stack aamount or the person was already all in
                return False
            if round == "preflop":
                if self.raiseCount == 0:
                    if raiseAmount == self.currentBet:
                        return False
                    if (self.currentBet > self.betAmounts[player][self.bettingRound] or self.currentPlayerPosition == self.bigBlindPosition):
                        minRaise = self.currentBet - self.betAmounts[player][self.bettingRound] + self.bigBlind
                        maxRaise = self.stacks[player] + self.betAmounts[player][self.bettingRound]
                        if minRaise <= 0:
                            return False
                        if minRaise <= maxRaise:
                            return (player != self.smallBlindPosition or minRaise >= self.bigBlind)
                        else:
                            return False
                elif self.raiseCount > 0:
                    if self.stacks[player] - raiseAmount == 0: #player went all in
                        return True
                    if self.currentBet < raiseAmount < self.stacks[player]:
                        return True
            else:
                if raiseAmount >= self.bigBlind:
                    return True
                else:
                    return False
        if move == "check":
            if self.bettingRound == "preflop":
                if self.raiseCount == 0:
                    if self.players.index(player) == self.bigBlindPosition:
                        return True
                    else:
                        return False
                if self.raiseCount > 0:
                    if self.currentBet == self.betAmounts[player][self.bettingRound]:
                        return True
                else:
                    return False
            else:
               if self.currentBet == self.betAmounts[player][self.bettingRound]:
                        return True 

        return False

def onAppStart(app):
    app.cx = 200
    app.cy = 200
    app.colorFold = "orange"
    app.colorCall = "green"
    app.colorRaise = "green"
    app.colorCheck = "green"
    app.raiseBox = False
    app.raiseAmount = ''
    app.error = False
    app.roundCounter = 0
    app.playerTimer = 0 
    app.elapsedTime = None
    app.players = None
    app.startNewGame = False
    #https://www.google.com/url?sa=i&url=https%3A%2F%2Fdepositphotos.com%2Fvector-images%2Fpoker-table.html&psig=AOvVaw1v5Bi6Xvnfj_SI5jw2RG6f&ust=1682281638987000&source=images&cd=vfe&ved=0CAQQjB1qFwoTCICpuM-pvv4CFQAAAAAdAAAAABAE
    app.tableImage = "/Users/aaryanlalwani/Desktop/TermProject -112/images/Screenshot 2023-04-17 at 5.50.52 PM.png"
    ## images have been taken from the website: https://www.pinterest.se/pin/247698048244855054/
    app.mainSplashScreen = "/Users/aaryanlalwani/Desktop/TermProject -112/images/pokerWallpaper.png"
    # plain card images have been taken from https://www.me.uk/cards/makeadeck.cgi
    app.plainCardImage = "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/2B.png"
#----------------------------------------------------------------
    app.borderT = "white"
    app.borderDp = "white"
    app.borderAi = "white"
    app.button_width = 200
    app.button_height = 50
    app.button_spacing = 240
    app.x = app.width/2 -300
    app.y = app.height/2-300
    app.showTexasSetup = False
    app.showDoublePokerSetup = False
    app.showAiSetup = False
    app.enterName = ["" for i in range(8)]
    app.enterStackAmount = ["" for i in range(8)]
    app.clickedOnBox = False
    app.clickedOnBoxS = False
    app.indexOfBox = None
    app.screen = "Enter Game"
    app.stackList = []
    app.playerName =  ["Enter Player Name" for name in range(8)]
    app.playerStack = ["Stack" for stack in range(8)]
    app.userNameAi = ["Your Name!"]
    app.userStackAi = ["Stack"]
    app.userBox = False
    app.userBoxs = False
    app.bestMove = None
    
#---------------------------------------------------
    app.game = None

#---------------------------------------------------Timer
    app.startTime = time.time()
    app.timeCount = 5
    app.showCards = False
    app.makeMove = False

def welcome_redrawAll(app):
    drawLabel("Welcome to The Game", app.width/2, app.height/2, size = 24)
    drawRect(0,0,app.width,app.height,fill="black")
    drawImage(app.mainSplashScreen, app.width/2,app.height/2,width=app.width,height=app.height-200, align='center')
    drawRect( app.x, app.y, app.button_width, app.button_height, fill="white",align="center", border = app.borderT,borderWidth = 9)
    drawLabel("Texas Hold'em",app.x, app.y,fill="black",size=24,align='center')
    # drawRect( app.x+app.button_spacing, app.y, app.button_width, app.button_height, fill="white",align="center",border = app.borderDp,borderWidth = 9)
    # drawLabel("Double Poker",app.x+app.button_spacing, app.y,fill="black",size=24,align='center')
    drawRect( app.x+(app.button_spacing*2), app.y, app.button_width, app.button_height, fill="white",align="center",border = app.borderAi,borderWidth = 9)
    drawLabel("Play against AI",app.x+(app.button_spacing*2), app.y,fill="black",size=24,align='center')
    drawRect(app.width/2, app.height-100, app.button_width, app.button_height, fill="white",align="center",border = "lightBlue",borderWidth = 5)
    drawLabel(f'{app.screen}',app.width/2, app.height-100,fill="black",size=24,align='center')

#--------------------------------------------------- (setup list and stacks)
    if app.showTexasSetup == True:
        centerX = app.width/2-160
        centerY = app.height/2-200
        rectangleWidth = 250
        rectangleHeight = 40
        for i in range (8):
            drawRect(centerX-100,centerY+(i*50),rectangleWidth,rectangleHeight,fill ="black",border="grey",borderWidth = 4)
            drawRect(centerX+160,centerY+(i*50),rectangleWidth/2,rectangleHeight,fill ="black",border = "grey",borderWidth = 4)
            if app.enterName[i] == "":
                name = app.playerName[i]
            else:
                name = app.enterName[i]
            drawLabel(name,centerX-15,centerY+(i*50)+20,align = "center",size=18,fill="white")
            if app.enterStackAmount[i] == "":
                stack = app.playerStack[i]
            else:
                stack = app.enterStackAmount[i]
            drawLabel(stack,centerX+225,centerY+(i*50)+20,align = "center",size=18,fill="white")

    if app.showAiSetup == True:
        centerX = app.width/2-160
        centerY = app.height/2-200
        rectangleWidth = 250
        rectangleHeight = 40
        for i in range (5):
            drawRect(centerX-100,centerY+(i*50),rectangleWidth,rectangleHeight,fill ="black",border="grey",borderWidth = 4)
            drawRect(centerX+160,centerY+(i*50),rectangleWidth/2,rectangleHeight,fill ="black",border = "grey",borderWidth = 4)
            if app.enterName[i] == "":
                name = app.playerName[i]
            else:
                name = app.enterName[i]
            drawLabel(name,centerX-15,centerY+(i*50)+20,align = "center",size=18,fill="white")
            if app.enterStackAmount[i] == "":
                stack = app.playerStack[i]
            else:
                stack = app.enterStackAmount[i]
            drawLabel(stack,centerX+225,centerY+(i*50)+20,align = "center",size=18,fill="white")
        drawRect(centerX-100,centerY+(5*50),rectangleWidth,rectangleHeight,fill ="black",border="beige",borderWidth = 4)
        drawLabel(app.userNameAi[0],centerX-15,centerY+(5*50)+20,align = "center",size=18,fill="white")
        drawRect(centerX+160,centerY+(5*50),rectangleWidth/2,rectangleHeight,fill ="black",border = "beige",borderWidth = 4)
        drawLabel(app.userStackAi[0] ,centerX+225,centerY+(5*50)+20,align = "center",size=18,fill="white")

def welcome_onKeyPress(app, key):
    # if key == '?':
    #     setActiveScreen('game')
    if app.clickedOnBox:
        if key in string.ascii_letters:  # Check if the key is a letter
            app.enterName[app.indexOfBox] += key
        elif key == 'backspace':  # Check if the key is the backspace key
            app.enterName[app.indexOfBox] = app.raiseAmount[:-1]  # Remove the last character from the raise amount
        elif key == "space":
            app.enterName[app.indexOfBox] += " "
        elif key == 'enter':  # Check if the key is the enter key
            app.playerName[app.indexOfBox] = app.enterName[app.indexOfBox]
            app.clickedOnBox  = False
        
    if app.clickedOnBoxS:
        if key in string.digits:  # Check if the key is a digit
            app.enterStackAmount[app.indexOfBox] += key
        elif key == 'backspace':  # Check if the key is the backspace key
            app.enterStackAmount[app.indexOfBox] = app.enterStackAmount[app.indexOfBox][:-1]  # Remove the last character from the stack amount
        elif key == 'enter':  # Check if the key is the enter key
            app.playerStack[app.indexOfBox] = app.enterStackAmount[app.indexOfBox]
            app.clickedOnBox = False

    if app.userBox == True:
        if key in string.ascii_letters:  # Check if the key is a letter
            app.userNameAi[0] += key
        elif key == 'backspace':  # Check if the key is the backspace key
            app.userNameAi[0] = app.raiseAmount[:-1]  # Remove the last character from the raise amount
        elif key == "space":
            app.userNameAi[0] += " "
        elif key == 'enter':  # Check if the key is the enter key
            app.userNameAi[0] = app.userNameAi[0]
            app.userBox  = False

    if app.userBoxs == True:
        if key in string.digits:  # Check if the key is a digit
            app.userStackAi[0] += key
        elif key == 'backspace':  # Check if the key is the backspace key
            app.userStackAi[0] = app.userStackAi[0][:-1]  # Remove the last character from the stack amount
        elif key == 'enter':  # Check if the key is the enter key
            app.userStackAi[0] = app.userStackAi[0]
            app.userBoxs = False
        
def welcome_onMousePress(app, mouseX, mouseY):
    texas_onMousePress(app, mouseX, mouseY)
    app.cx = mouseX
    app.cy = mouseY
    if app.x-(app.button_width/2) <= app.cx <= (app.x + app.button_width/2) and (app.y-(app.button_height/2) <= app.cy <= app.y + (app.button_height/2)):
        app.showTexasSetup = True
        app.showDoublePokerSetup = False
        app.showAiSetup = False
        app.screen = "Texas Hold'em"
        app.borderT = "grey"
        # Call a function to handle the Texas Hold'em game

    elif (app.x-(app.button_width/2) + app.button_spacing <=  app.cx<= (app.x + app.button_width/2) + app.button_spacing  ) and (app.y-(app.button_height/2) <= app.cy <= app.y + (app.button_height/2)):
        app.showDoublePokerSetup = True
        app.showAiSetup = False
        app.showTexasSetup = False
        app.screen = "Double Poker"
        app.borderDp = "grey"
        # Call a function to handle the Double Poker game

    elif (app.x-(app.button_width/2) + app.button_spacing*2 <=  app.cx <= (app.x + app.button_width/2)+ app.button_spacing*2 ) and (app.y-(app.button_height/2) <= app.cy <= app.y + (app.button_height/2)):
        app.showAiSetup = True
        app.showTexasSetup = False
        app.showDoublePokerSetup = False
        app.screen = "Play against AI"
        app.borderAi = "grey"

    if app.showAiSetup == True:
        centerX = app.width/2-160
        centerY = app.height/2-200
        rectangleWidth = 250
        rectangleHeight = 40
        if centerX-100 <= mouseX <= centerX-100+rectangleWidth and centerY+(5*50) <= mouseY <= centerY+(5*50)+rectangleHeight:
            app.userBox = True
            app.userNameAi[0] = ""
        elif centerX+160 <= mouseX <= centerX+160+rectangleWidth/2 and centerY+(5*50) <= mouseY <= centerY+(5*50)+rectangleHeight:
            app.userBoxs = True
            app.userStackAi[0] = ""

    
    elif app.width/2 - app.button_width/2 <= mouseX <= app.width/2 + app.button_width/2 \
        and app.height-100 - app.button_height/2 <= mouseY <= app.height-100 + app.button_height/2:
        if app.screen != "Enter Game":
            playerList = []
            stackList = []
            for i in app.enterName:
                if i  == "" or i == "Enter Player Name":
                    continue
                else:
                    playerList.append(i)
            for e in app.enterStackAmount:
                if e == "" or e == "Stack":
                    continue
                else:
                    stackList.append(int(e))  # convert to integer
            playerDict = {}
            for i in range (len(playerList)):
                playerDict[playerList[i]] = stackList[i]
            if len(playerDict) >=2:
                if app.screen == "Texas Hold'em":
                    app.game = TexasHoldem(playerDict)

            else:
                print("Error: Must have at least 2 players to play Texas Hold'em")

            if app.screen == "Texas Hold'em":
                    setActiveScreen('game')
            elif app.screen == "Double Poker":
                    setActiveScreen('game2')
            elif app.screen == "Play against AI":
                    setActiveScreen('game')
    if app.screen == "Play against AI":
        if app.width/2 - app.button_width/2 <= mouseX <= app.width/2 + app.button_width/2 and app.height-100 - app.button_height/2 <= mouseY <= app.height-100 + app.button_height/2:
            if app.screen != "Enter Game":
                playerList = []
                stackList = []
                for i in app.enterName:
                    if i  == "" or i == "Enter Player Name":
                        continue
                    else:
                        if i == app.userNameAi[0]:
                            continue
                        else:
                            i+="AI"
                            playerList.append(i)
                for e in app.enterStackAmount:
                    if e == "" or e == "Stack":
                        continue
                    else:
                        stackList.append(int(e))  # convert to integer

                playerList.append(app.userNameAi[0])
                stackList.append(int(app.userStackAi[0]))
                playerDict = {}
                for i in range (len(playerList)):
                    playerDict[playerList[i]] = stackList[i]
                if len(playerDict) >=2:
                    if app.screen == "Play against AI":
                        app.game = TexasHoldem(playerDict)
                else:
                    print("Error: Must have at least 2 players to play Texas Hold'em")

        
                
            setActiveScreen('game')
    
def texas_onMousePress(app, mouseX, mouseY):
    if app.showTexasSetup == True or app.showDoublePokerSetup == True or app.showAiSetup == True:
        centerX = app.width/2-160
        centerY = app.height/2-200
        rectangleWidth = 250
        rectangleHeight = 40
        for i in range(8):
            # Check if the mouse is clicked inside the name box
            nameBoxX = centerX-100
            nameBoxY = centerY + (i * 50)
            if nameBoxX <= mouseX <= nameBoxX + rectangleWidth and nameBoxY <= mouseY <= nameBoxY + rectangleHeight:
                app.playerName[i] = app.enterName[i]
                app.clickedOnBox = True
                app.indexOfBox = i
            # Check if the mouse is clicked inside the stack box
            stackBoxX = centerX +160  
            stackBoxY = centerY + (i * 50)
            if stackBoxX <= mouseX <= stackBoxX + rectangleWidth/2 and stackBoxY <= mouseY <= stackBoxY + rectangleHeight:
                app.playerStack[i] = app.enterStackAmount[i]
                app.clickedOnBoxS = True
                app.indexOfBox = i

def game_redrawAll(app):
    drawRect(0,0,app.width,app.height,fill="black")
    drawLabel(f"{app.game.currentPlayer}'s Turn",app.width/2,app.height/2,fill="black",size=16)
    drawImage(app.tableImage, app.width/2,app.height/2-100,width=app.width+300,height=app.height-200, align='center')
    drawOval(app.width/2,(app.height/2)-120,100,50,fill="white",opacity = 20)
    drawLabel(f'{app.game.potSize}',app.width/2,(app.height/2)-120, size=20,bold = True)
    drawLabel(f"{app.game.currentPlayer}'s Turn",app.width/2,(app.height/8)-100,fill="white",size=24,bold=True)
    drawRect(app.width-100, app.height-100, app.button_width/2, app.button_height, fill="white",align="center",border = "lightBlue",borderWidth = 5)
    drawLabel("Best Move",app.width-100, app.height-100,fill="black",size=16,align='center')
    drawRect(app.width-100, app.height-200, app.button_width, app.button_height, fill="white",align="center",border = "lightBlue",borderWidth = 5)
    drawLabel(f'{app.bestMove}',app.width-100, app.height-200,fill="black",size=16,align='center')
    drawLabel(f'Pot Odds: {app.game.potOdds()}%',874,100,fill="white",size=16,bold= True)
    # Draw player info
    for i in range(len(app.game.players)):
        length = 130
        width = 60
        centerX = app.width/2 + 410 * math.cos(math.pi/2 + i*math.pi/4)
        centerY = app.height/2 - 280 * math.sin(math.pi/2 + i*math.pi/4)
        drawRect(centerX - length/2, centerY - width/2-40, length, width, fill="black",opacity= 70,border="grey")
        drawLabel(app.game.players[i], centerX, centerY-25, fill="white", size=16,opacity=100,bold=True)
        drawLabel(app.game.stacks[app.game.players[i]], centerX, centerY-50, fill="white", size=16,opacity = 100,bold=True)

        # Draw dealer, big blind, and small blind indicators
        if i == app.game.dealerPosition:
            drawCircle(centerX+50, centerY, 20, fill="white")
            drawLabel("D", centerX+50, centerY, size=16, bold=True)
        if i == app.game.bigBlindPosition:
            drawCircle(centerX+50, centerY, 20, fill="blue")
            drawLabel("BB", centerX+50, centerY, size=16, bold=True, fill="white")
        elif i == app.game.smallBlindPosition:
            drawCircle(centerX+50, centerY, 20, fill="grey")
            drawLabel("SB", centerX+50, centerY, size=16, bold=True, fill="black")

        image = drawImages()
        if app.game.currentPlayerPosition == i:
            if app.showCards == True:
                card1, card2 = image.drawCard(app.game.holeCards[app.game.players[i]][0], app.game.holeCards[app.game.players[i]][1])
            else:
                card1,card2 = app.plainCardImage,app.plainCardImage
            
            if app.game.gameOver == False:
                drawImage(card1, centerX-50, centerY-160, width=45, height=80)
                drawImage(card2, centerX, centerY-160, width=45, height=80)
            else:
                for j in range(len(app.game.players)):
                    if j not in app.game.foldedPlayers:
                        centerX2 = app.width/2 + 410 * math.cos(math.pi/2 + j*math.pi/4)
                        centerY2 = app.height/2 - 280 * math.sin(math.pi/2 + j*math.pi/4)
                        card1, card2 = image.drawCard(app.game.holeCards[app.game.players[j]][0], app.game.holeCards[app.game.players[j]][1])
                        drawImage(card1, centerX2-50, centerY2-160, width=45, height=80)
                        drawImage(card2, centerX2 , centerY2-160, width=45, height=80)
                    else:
                        drawImage(app.plainCardImage, centerX-50 + 50*j, centerY-160, width=45, height=80)
                        drawImage(app.plainCardImage, centerX + 50*j, centerY-160, width=45, height=80)
        else:
            drawImage(app.plainCardImage, centerX-50, centerY-160, width=45, height=80)
            drawImage(app.plainCardImage, centerX, centerY-160, width=45, height=80)
    if len(app.game.communityCards) > 0:
        #drawLabel(app.game.communityCards, centerX, app.width/2, size=13,fill="white")
        cardSpacing = 80 # adjust this value to change the spacing between cards
        for i in range(len(app.game.communityCards)):
            img = image.getImage(app.game.communityCards[i])
            cardX = app.width/2 + (i - len(app.game.communityCards)/2) * cardSpacing
            drawImage(img, cardX, (app.height/2)-80, width=60, height=100)
    drawLabel(f'round: {app.game.bettingRound}', (app.height/2)+20, (app.width/2)+350, size=12,fill="white",bold=True)
    if app.game.gameOver == True:
        drawRect(app.width/2-65, app.height/2-30, length, width, fill="black",opacity= 70,border="grey")
        drawLabel("Next Round", app.width/2, app.height/2, fill="white", size=16,opacity=100,bold=True)


    # Draw fold, call, check, and raise options
    centerX = app.width/2 + 100
    centerY = app.height/2 + 250
    drawRect(centerX+100,centerY+100,100,50,fill = None,border = app.colorFold,borderWidth = 4)
    drawLabel("FOLD",centerX+150,centerY+125,fill =app.colorFold,size=16,align="center",bold=True)
    drawRect(centerX-50,centerY+100,100,50,fill =None,border =app.colorCheck,borderWidth = 4)
    drawLabel("CHECK",centerX,centerY+125,fill =app.colorCheck,size=16,align="center",bold=True)
    drawRect(centerX-250,centerY+100,100,50,fill =None,border = app.colorRaise,borderWidth = 4)
    drawLabel("RAISE",centerX-200,centerY+125,fill =app.colorRaise,size=16,align="center",bold=True)
    drawRect(centerX-400,centerY+100,100,50,fill =None,border = app.colorCall,borderWidth = 4)
    drawLabel("CALL",centerX-350,centerY+125,fill =app.colorCall,size=16,align="center",bold=True)

    # drawLabel(f'{app.game.currentBet}',(app.width/2),(app.height/20),size=25,bold=True,align="center",fill="white")
    drawLabel(f'{app.game.roundCounter}',app.height/2+400, app.width/2-450, size=25,fill="white",bold=True)
    #Raise Amount box
    if app.raiseBox == True:
        drawRect(centerX-250,centerY+25,100,50,fill =None,border="white")
        drawLabel(f"Amount = {app.raiseAmount}",centerX-200,centerY+50,fill="white")
    #error protection
    if app.error == True:
        drawLabel("Invalid",app.width/2,app.height/2+325,size=25,bold=True,align="center",fill="white")
    if app.showAiSetup == True:
        drawRect(centerX-550,centerY+100,100,50,fill ="black",border="cyan",opacity = 40,borderWidth = 4)
        drawLabel("Make AI Move",centerX-500,centerY+125,fill="white",align = "center")

def game_onStep(app):
    elapsedTime = time.time() - app.startTime
    if elapsedTime >= 1:
        app.timeCount -= 1
    if app.timeCount <= 0:
        app.showCards = True
    if app.makeMove == True:
        app.timeCount = 50
        app.makeMove = False

        #reset the time and 2 implement the game logic saying show the cards 

def game_onMousePress(app, mouseX, mouseY):
    app.cx = mouseX
    app.cy = mouseY
    centerX = app.width/2 + 100
    centerY = app.height/2 + 250
    length = 130
    width = 60
    if app.screen == "Texas Hold'em" or (app.screen == "Play against AI" and app.game.currentPlayer == app.userNameAi[0]):
        if app.game.gameOver == True:
            app.startNewGame = True

        if app.startNewGame == True:
            if (app.width/2 - length/2) <= mouseX <= (app.width/2 + length/2) and (app.height/2 - width/2) <= mouseY <= (app.height/2 + width/2):
                # code to be executed when button is clicked
                app.game.newRound()
        if app.game.gameOver == False:
            app.cx = mouseX
            app.cy = mouseY
            centerX = app.width/2 + 100
            centerY = app.height/2 + 250

            if centerX-400 <= app.cx <= centerX-300 and centerY+100 <= app.cy <= centerY+150:
                app.colorCall = "lightGreen"
                player = app.game.currentPlayer
                move = "call"
                if app.game.isLegalMove(player, move):
                    app.game.runBettingRound(player, move)
                    app.makeMove = True
                    app.showCards = False
                    app.timeCount = 10
                    app.error = False
                    app.raiseBox == False
                    app.bestMove = None
                else:
                    app.error = True
            elif centerX-250 <= app.cx <= centerX-150 and centerY+100 <= app.cy <= centerY+150:
                app.colorRaise = "lightGreen"
                app.raiseBox = True
                player = app.game.currentPlayer
                move = "raise"
            elif centerX-50 <= app.cx <= centerX+50 and centerY+100 <= app.cy <= centerY+150:
                app.colorCheck = "lightGreen"
                player = app.game.currentPlayer
                move = "check"
                if app.game.isLegalMove(player, move):
                    app.game.runBettingRound(player, move)
                    app.makeMove = True
                    app.showCards = False
                    app.timeCount = 10
                    app.error = False
                    app.raiseBox == False
                    app.bestMove = None
                else:
                    app.error = True
            elif centerX+100 <= app.cx <= centerX+200 and centerY+100 <= app.cy <= centerY+150:
                app.colorFold = "purple"
                player = app.game.currentPlayer
                move = "fold"
                if app.game.isLegalMove(player, move):
                    app.game.runBettingRound(player, move)
                    app.makeMove = True
                    app.showCards = False
                    app.timeCount = 10
                    app.error = False
                    app.raiseBox == False
                    app.bestMove = None
                else:
                    app.error = True

    if app.width-100 - app.button_width/2 <= mouseX <= app.width-100 + app.button_width/2 and app.height-100 - app.button_height/2 <= mouseY <= app.height-100 + app.button_height/2:
        app.bestMove = (app.game.getBestMove())
    if app.screen == "Play against AI":
        if centerX-550 <= app.cx <= centerX-450 and centerY+100 <= app.cy <= centerY+150:
            playerAI = app.game.currentPlayer
            if playerAI != app.userNameAi[0]: 
                bestMove,ifRaise = app.game.getBestMove()
                ifRaise = ifRaise if ifRaise > app.game.bigBlind*2 else 0
                bestMove = str(bestMove)
                if bestMove == "fold":
                    bestMove = bestMove
                elif bestMove == "call":
                    if app.game.isLegalMove(playerAI, bestMove):
                        bestMove = "call"
                    else:
                        bestMove = "check"

                elif bestMove == "raise":
                    ifRaise = int(ifRaise)
                    if app.game.isLegalMove(playerAI, bestMove,ifRaise):
                        bestMove = "raise"
                    else:
                        if ifRaise < app.game.bigBlind:
                            ifRaise = ifRaise*2                      
                print(bestMove,ifRaise)
                app.game.runBettingRound(playerAI, bestMove,ifRaise)
            if playerAI == app.userNameAi[0]:
                if centerX-400 <= app.cx <= centerX-300 and centerY+100 <= app.cy <= centerY+150:
                    app.colorCall = "lightGreen"
                    player = app.game.currentPlayer
                    move = "call"
                    if app.game.isLegalMove(player, move):
                        app.game.runBettingRound(player, move)
                        app.makeMove = True
                        app.showCards = False
                        app.timeCount = 10
                        app.error = False
                        app.raiseBox == False
                        app.bestMove = None
                    else:
                        app.error = True
                elif centerX-250 <= app.cx <= centerX-150 and centerY+100 <= app.cy <= centerY+150:
                    app.colorRaise = "lightGreen"
                    app.raiseBox = True
                    player = app.game.currentPlayer
                    move = "raise"
                elif centerX-50 <= app.cx <= centerX+50 and centerY+100 <= app.cy <= centerY+150:
                    app.colorCheck = "lightGreen"
                    player = app.game.currentPlayer
                    move = "check"
                    if app.game.isLegalMove(player, move):
                        app.game.runBettingRound(player, move)
                        app.makeMove = True
                        app.showCards = False
                        app.timeCount = 10
                        app.error = False
                        app.raiseBox == False
                        app.bestMove = None
                    else:
                        app.error = True
                elif centerX+100 <= app.cx <= centerX+200 and centerY+100 <= app.cy <= centerY+150:
                    app.colorFold = "purple"
                    player = app.game.currentPlayer
                    move = "fold"
                    if app.game.isLegalMove(player, move):
                        app.game.runBettingRound(player, move)
                        app.makeMove = True
                        app.showCards = False
                        app.timeCount = 10
                        app.error = False
                        app.raiseBox == False
                        app.bestMove = None
                    else:
                        app.error = True

def game_onMouseRelease(app, mouseX, mouseY):
    app.colorFold = "orange"
    app.colorCall = "green"
    app.colorCheck = "green"
    app.colorRaise = "green"

def game_onKeyPress(app, key):
    player = app.game.currentPlayer
    move = "raise"
    if app.raiseBox == True:
        if key.isdigit():  # Check if the key is a digit
            app.raiseAmount += key
        elif key == 'backspace':  # Check if the key is the backspace key
            app.raiseAmount = app.raiseAmount[:-1]  # Remove the last character from the raise amount
        elif key == 'enter':  # Check if the key is the enter key
            amount = int(app.raiseAmount)  # Convert the raise amount to an integer
            if app.game.isLegalMove(player, move,amount):
                player = app.game.currentPlayer
                move = "raise"
                app.game.raiseOccurred = True
                app.game.runBettingRound(player, move, amount)
                app.raiseAmount = ''  # Reset the raise amount
                app.raiseBox = False
                app.makeMove = True
                app.showCards = False
                app.timeCount = 20
                app.error = False  
            else:
                app.error = True

class drawImages:
    # images have been taken from the website: https://www.me.uk/cards/makeadeck.cgi
    def __init__(self):
        self.cardDict = {"Deuce of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/2C.png",
    "Three of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/3C.png",
    "Four of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/4C.png",
    "Five of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/5C.png",
    "Six of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/6C.png",
    "Seven of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/7C.png",
    "Eight of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/8C.png",
    "Nine of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/9C.png",
    "Ten of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/TC.png",
    "Jack of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/JC.png",
    "Queen of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/QC.png",
    "King of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/KC.png",
    "Ace of Clubs": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/AC.png",
    "Deuce of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/2D.png",
    "Three of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/3D.png",
    "Four of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/4D.png",
    "Five of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/5D.png",
    "Six of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/6D.png",
    "Seven of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/7D.png",
    "Eight of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/8D.png",
    "Nine of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/9D.png",
    "Ten of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/TD.png",
    "Jack of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/JD.png",
    "Queen of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/QD.png",
    "King of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/KD.png",
    "Ace of Diamonds": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/AD.png",
    "Deuce of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/2H.png",
    "Three of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/3H.png",
    "Four of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/4H.png",
    "Five of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/5H.png",
    "Six of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/6H.png",
    "Seven of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/7H.png",
    "Eight of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/8H.png",
    "Nine of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/9H.png",
    "Ten of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/TH.png",
    "Jack of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/JH.png",
    "Queen of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/QH.png",
    "King of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/KH.png",
    "Ace of Hearts": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/AH.png",
    "Deuce of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/2S.png",
    "Three of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/3S.png",
    "Four of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/4S.png",
    "Five of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/5S.png",
    "Six of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/6S.png",
    "Seven of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/7S.png",
    "Eight of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/8S.png",
    "Nine of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/9S.png",
    "Ten of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/TS.png",
    "Jack of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/JS.png",
    "Queen of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/QS.png",
    "King of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/KS.png",
    "Ace of Spades": "/Users/aaryanlalwani/Desktop/TermProject -112/images/CardImages/AS.png"}

    def drawCard(self,card1,card2):
        rcard1 = None
        rcard2 = None
        card1 = str(card1)
        card2 = str(card2)
        for i in self.cardDict:
            if i == card1:
                rcard1 = self.cardDict[i]
            if i == card2:
                rcard2 = self.cardDict[i]
        return rcard1,rcard2

    def getImage(self,i):
        result = None
        i =str(i)
        for e in self.cardDict:
            if i == e:
                result = self.cardDict[i]
        return result

def main():

    runAppWithScreens(initialScreen='welcome', width=1000, height=1000)

if __name__ == '__main__':
    main()
