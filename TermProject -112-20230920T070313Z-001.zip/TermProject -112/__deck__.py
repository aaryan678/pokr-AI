import random

class Card:
    def __init__(self, value, suit, rank):
        # Initialize a card object with a value suit and a rank
        self.value = value
        self.suit = suit
        self.rank = rank
        
    def __repr__(self):
        # Return a string representation of the card
        return f"{self.value} of {self.suit}"
    
    
class StandardDeck(list):
    def __init__(self):
        # Define the possible suits and values for a standard deck of cards
        suits = ["Hearts", "Spades", "Diamonds", "Clubs"]
        values = {
            "Deuce": 2,
            "Three": 3,
            "Four": 4,
            "Five": 5,
            "Six": 6,
            "Seven": 7,
            "Eight": 8,
            "Nine": 9,
            "Ten": 10,
            "Jack": 11,
            "Queen": 12,
            "King": 13,
            "Ace": 14
        }
        # Add a Card object to the deck for each combination of suit, value 
        # and rank
        for suit in suits:
            for value, rank in values.items():
                card = Card(value, suit, rank)
                self.append(card)
 
    def shuffle(self):
        # Shuffle the deck in place
        random.shuffle(self)
        
# class when called returns a shuffled deck (which is a list)       
class ShuffledDeck(StandardDeck):
    def __init__(self):
        StandardDeck.__init__(self)
        return self.shuffle()

